// Importando styled-components
import { createGlobalStyle } from 'styled-components';

// Definindo os estilos globais
const GlobalStyle = createGlobalStyle`
  * {
    text-decoration: none;
    list-style: none;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Roboto', sans-serif;
  }

  body {
    background-color: #f4f4f9; /* Fundo cinza claro suave */
    color: #333333; /* Texto em cinza escuro */
    font-family: 'Arial', sans-serif;
  }

  a {
    text-decoration: none;
  }

  // Outros estilos globais
`;

export default GlobalStyle;
