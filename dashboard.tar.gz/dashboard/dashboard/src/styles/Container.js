import styled from 'styled-components';

export const Container = styled.div`
  height: 100vh;            /* Garante que o contêiner ocupe a altura total da tela */
  padding: 16px;
  box-sizing: border-box;

`;
