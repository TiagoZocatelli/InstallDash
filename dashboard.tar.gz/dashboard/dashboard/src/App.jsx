import { useState, useEffect } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import SalesBarChart from './containers/Dashboard/VendasMes/VendasMes';
import FaturamentoChart from './containers/Dashboard/Faturamento/FaturamentoChart';
import VendasDia from './containers/Dashboard/VendasDia/VendasDia'; 
import GlobalStyle from './styles/global';
import Header from './containers/Header/index';
import { Container } from './styles/Container';
import Departamento from './containers/Dashboard/Departamento/index';
import { fetchVendasAndFaturamento } from './api/API';
import ComparativoAno from './containers/Dashboard/CompativoAno/Compativo';
import FinalizadorasOnline from './containers/Dashboard/VendasOnline/VendasOn';
import FinalizadorasPeriodo from './containers/Dashboard/Finalizadoras/Finalizadoras';
import Login from './containers/Login/Login';
import PrivateRoute from './components/PrivateRoute';
import Register from './containers/Login/Register';

function App() {
    const [vendasMensais, setVendasMensais] = useState(null);
    const [vendasDia, setVendasDia] = useState(null);
    const [faturamentoData, setFaturamentoData] = useState(null);
    const [isAuthenticated, setIsAuthenticated] = useState(() => {
        return localStorage.getItem('isAuthenticated') === 'true'; // Retrieve authentication state
    });
    const [loading, setLoading] = useState(true);

    const getStartDate = () => {
        const now = new Date();
        return new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0];
    };

    const getEndDate = () => {
        return new Date().toISOString().split('T')[0];
    };

    const startDate = getStartDate();
    const endDate = getEndDate();

    const fetchAndDisplayData = async () => {
        try {
            const { resumoPorFilial, vendasMensais, vendasDia } = await fetchVendasAndFaturamento(startDate, endDate);
            setVendasMensais(vendasMensais);
            setVendasDia(vendasDia);
            setFaturamentoData(resumoPorFilial);
        } catch (error) {
            console.error('Erro ao buscar dados:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (isAuthenticated) {
            fetchAndDisplayData();
        } else {
            setLoading(false);
        }
    }, [isAuthenticated]);

    return (
        <>
            <GlobalStyle />
            {isAuthenticated ? (
                <>
                    <Header setIsAuthenticated={setIsAuthenticated} /> {/* Pass setIsAuthenticated */}
                    <Container>
                        {loading ? (
                            <p>Carregando...</p>
                        ) : (
                            <Routes>
                                <Route element={<PrivateRoute isAuthenticated={isAuthenticated} />}>
                                    <Route
                                        path="/"
                                        element={
                                            <div className="App">
                                                {vendasMensais ? <SalesBarChart vendasMensais={vendasMensais} /> : <p>Carregando...</p>}
                                                <ComparativoAno />
                                                {vendasDia ? <VendasDia vendasDia={vendasDia} /> : <p>Carregando...</p>}
                                                {faturamentoData ? <FaturamentoChart faturamentoData={faturamentoData} /> : <p>Carregando...</p>}
                                            </div>
                                        }
                                    />
                                    <Route path="/Departamento" element={<Departamento />} />
                                    <Route path="/VendasOnline" element={<FinalizadorasOnline />} />
                                    <Route path="/Finalizadoras" element={<FinalizadorasPeriodo />} />
                                </Route>
                            </Routes>
                        )}
                    </Container>
                </>
            ) : (
                <Routes>
                    <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
                    <Route path="register" element={<Register />} />
                    <Route path="*" element={<Login setIsAuthenticated={setIsAuthenticated} />} /> {/* Redirects any other route to login */}
                </Routes>
            )}
        </>
    );
}

export default App;
