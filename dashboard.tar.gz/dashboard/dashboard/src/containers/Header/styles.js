import styled from 'styled-components';

export const Navbar = styled.nav`
  background-color: #102C57; /* Azul suave */
  padding: 1rem 2rem;
  box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.3);
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

export const NavbarBrand = styled.a`
  font-size: 1.8rem;
  font-weight: bold;
  color: #fff; /* Azul escuro */
  text-decoration: none;

  &:hover {
    color: #f0f0f0; /* Cinza claro */
  }
`;

export const Hamburger = styled.div`
  display: none;
  flex-direction: column;
  cursor: pointer;

  span {
    height: 2px;
    width: 25px;
    background: #f0f0f0; /* Cinza claro */
    margin-bottom: 4px;
    border-radius: 1px;
  }

  @media (max-width: 768px) {
    display: flex;
  }
`;

export const NavbarMenu = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-grow: 1;

  @media (max-width: 768px) {
    display: none;
  }
`;

export const NavListLeft = styled.ul`
  display: flex;
  align-items: center;
  list-style: none;
  padding: 0;
  margin: 0;
`;

export const NavListRight = styled.ul``;

export const AsideMenu = styled.aside`
  position: fixed;
  top: 0;
  left: 0;
  height: 100%;
  width: 250px;
  background-color: #102C57; /* Azul suave */
  padding: 2rem 1rem;
  box-shadow: 2px 0 12px rgba(0, 0, 0, 0.2);
  transform: ${(props) => (props.$isOpen ? 'translateX(0)' : 'translateX(-100%)')};
  transition: transform 0.3s ease-in-out;
  z-index: 1000;

  @media (min-width: 769px) {
    display: none;
  }
`;

export const CloseButton = styled.button`
  background: none;
  border: none;
  color: #f0f0f0; /* Cinza claro */
  font-size: 1.5rem;
  position: absolute;
  top: 1rem;
  right: 1rem;
  cursor: pointer;
  z-index: 1001;
  padding: 0.5rem;
`;

export const NavList = styled.ul`
  display: flex;
  flex-direction: column;
  list-style: none;
  padding: 0;
  margin: 0;

  @media (min-width: 769px) {
    flex-direction: row;
  }
`;

export const NavItem = styled.li`
  margin-bottom: 1rem;
  position: relative;
  cursor: pointer;

  @media (min-width: 769px) {
    margin-bottom: 0;
    margin-left: 2rem;
  }
`;

export const NavLink = styled.a`
  color: #f0f0f0; /* Cinza claro */
  text-decoration: none;
  padding: 0.5rem 1rem;
  font-size: 1.2rem;
  font-weight: 500;
  display: block;

  &:hover {
    color: #e0e0e0; /* Cor clara para hover */
  }
`;

export const DropdownMenu = styled.div`
  display: none;
  position: absolute;
  top: 100%;
  left: 0;
  background-color: #1f4b99; /* Azul escuro */
  box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
  padding: 0.5rem 0;
  border-radius: 0.5rem;
  z-index: 999;

  ${NavItem}:hover & {
    display: block;
  }
`;

export const DropdownItem = styled.a`
  display: block;
  color: #f0f0f0; /* Cinza claro */
  padding: 0.5rem 1rem;
  text-decoration: none;
  white-space: nowrap;

  &:hover {
    background-color: #16407f; /* Azul mais escuro */
    color: #e0e0e0; /* Cor clara para hover */
  }
`;

export const SubNavList = styled.ul`
  list-style: none;
  padding-left: 1rem;
  margin: 0.5rem 0 0 0;
  border-left: 2px solid #e0e0e0; /* Cor clara */
`;

export const SubNavItem = styled.li`
  margin-bottom: 0.5rem;
`;

export const SubNavLink = styled.a`
  color: #f0f0f0; /* Cinza claro */
  text-decoration: none;
  padding: 0.3rem 1rem;
  cursor: pointer;
  font-size: 1rem;
  font-weight: 400;
  display: block;

  &:hover {
    color: #e0e0e0; /* Cor clara para hover */
  }
`;