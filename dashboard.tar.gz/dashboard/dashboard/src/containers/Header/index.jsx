import { useState, useEffect } from 'react';
import { FaSignOutAlt } from 'react-icons/fa';  // Import the icon
import { useNavigate } from 'react-router-dom';
import {
    Navbar,
    NavbarBrand,
    NavbarMenu,
    Hamburger,
    AsideMenu,
    CloseButton,
    NavList,
    NavItem,
    NavLink,
    SubNavList,
    SubNavItem,
    SubNavLink,
    DropdownMenu,
    DropdownItem
} from './styles';

const Header = () => {
    const [isVendasOpen, setIsVendasOpen] = useState(false);
    const [isDespesasOpen, setIsDespesasOpen] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
    const navigate = useNavigate();

    const toggleVendas = () => {
        setIsVendasOpen(!isVendasOpen);
        if (!isVendasOpen) setIsDespesasOpen(false);
    };

    const toggleDespesas = () => {
        setIsDespesasOpen(!isDespesasOpen);
        if (!isDespesasOpen) setIsVendasOpen(false);
    };

    const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

    useEffect(() => {
        const handleResize = () => setIsMobile(window.innerWidth <= 768);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const handleNavigation = (path) => {
        navigate(path);
        setIsMenuOpen(false); // Close the menu on mobile after navigation
    };

    return (
        <div>
            <Navbar>
                <NavbarBrand href="/">Dashboard</NavbarBrand>
                {!isMobile && (
                    <NavbarMenu>
                        <NavList style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                            <div style={{ display: 'flex' }}>
                                <NavItem>
                                    <NavLink className="dropdown-toggle" onClick={toggleVendas}>
                                        Vendas
                                    </NavLink>
                                    {isVendasOpen && (
                                        <DropdownMenu>
                                            <DropdownItem onClick={() => handleNavigation('/Departamento')}>
                                                Vendas por departamento
                                            </DropdownItem>
                                            <DropdownItem onClick={() => handleNavigation('/VendasOnline')}>
                                                Vendas Online
                                            </DropdownItem>
                                            <DropdownItem onClick={() => handleNavigation('/Finalizadoras')}>
                                                Finalizadoras
                                            </DropdownItem>
                                        </DropdownMenu>
                                    )}
                                </NavItem>

                                <NavItem>
                                    <NavLink className="dropdown-toggle" onClick={toggleDespesas}>
                                        Despesas
                                    </NavLink>
                                    {isDespesasOpen && (
                                        <DropdownMenu>
                                            <DropdownItem onClick={() => handleNavigation('/despesas/detalhes')}>
                                                Detalhes de Despesas
                                            </DropdownItem>
                                            <DropdownItem onClick={() => handleNavigation('/despesas/relatorio')}>
                                                Relatório de Despesas
                                            </DropdownItem>
                                        </DropdownMenu>
                                    )}
                                </NavItem>
                            </div>

                            <NavItem>
                                <NavLink href="/logout" style={{ marginLeft: 'auto' }}>
                                    <FaSignOutAlt /> Sair
                                </NavLink>
                            </NavItem>
                        </NavList>
                    </NavbarMenu>
                )}
                {isMobile && (
                    <Hamburger onClick={toggleMenu}>
                        <span></span>
                        <span></span>
                        <span></span>
                    </Hamburger>
                )}
            </Navbar>

            {isMobile && (
                <AsideMenu $isOpen={isMenuOpen}>
                    <CloseButton onClick={toggleMenu}>×</CloseButton>
                    <NavList>
                        <NavItem>
                            <NavLink className="dropdown-toggle" onClick={toggleVendas}>
                                Vendas
                            </NavLink>
                            {isVendasOpen && (
                                <SubNavList>
                                    <SubNavItem>
                                        <SubNavLink onClick={() => handleNavigation('/Departamento')}>
                                        Vendas por departamento
                                        </SubNavLink>
                                    </SubNavItem>
                                    <SubNavItem>
                                        <SubNavLink onClick={() => handleNavigation('/VendasOnline')}>
                                        Vendas Online
                                        </SubNavLink>
                                        <SubNavLink onClick={() => handleNavigation('/Finalizadoras')}>
                                        Finalizadoras
                                        </SubNavLink>
                                    </SubNavItem>
                                </SubNavList>
                            )}
                        </NavItem>

                        <NavItem>
                            <NavLink className="dropdown-toggle" onClick={toggleDespesas}>
                                Despesas
                            </NavLink>
                            {isDespesasOpen && (
                                <SubNavList>
                                    <SubNavItem>
                                        <SubNavLink onClick={() => handleNavigation('/despesas/detalhes')}>
                                            Detalhes de Despesas
                                        </SubNavLink>
                                    </SubNavItem>
                                    <SubNavItem>
                                        <SubNavLink onClick={() => handleNavigation('/despesas/relatorio')}>
                                            Relatório de Despesas
                                        </SubNavLink>
                                    </SubNavItem>
                                </SubNavList>
                            )}
                        </NavItem>

                        <NavItem>
                            <NavLink href="/logout">
                                <FaSignOutAlt /> Sair
                            </NavLink>
                        </NavItem>
                    </NavList>
                </AsideMenu>
            )}
        </div>
    );
};

export default Header;
