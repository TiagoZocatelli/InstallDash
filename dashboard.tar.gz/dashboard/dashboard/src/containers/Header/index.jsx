import { useState, useEffect } from 'react';
import { FaSignOutAlt } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import {
    Navbar,
    NavbarBrand,
    NavbarMenu,
    Hamburger,
    AsideMenu,
    CloseButton,
    NavList,
    NavItem,
    NavLink,
    SubNavList,
    SubNavItem,
    SubNavLink,
    DropdownMenu,
    DropdownItem
} from './styles';

const Header = ({ setIsAuthenticated }) => {
    const [isVendasOpen, setIsVendasOpen] = useState(false);
    const [isDespesasOpen, setIsDespesasOpen] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
    const navigate = useNavigate();

    const toggleVendas = () => {
        setIsVendasOpen(!isVendasOpen);
        if (!isVendasOpen) setIsDespesasOpen(false);
    };

    const toggleDespesas = () => {
        setIsDespesasOpen(!isDespesasOpen);
        if (!isDespesasOpen) setIsVendasOpen(false);
    };

    const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

    useEffect(() => {
        const handleResize = () => setIsMobile(window.innerWidth <= 768);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const handleNavigation = (path) => {
        navigate(path);
        setIsMenuOpen(false);
    };

    const handleLogout = () => {
        localStorage.removeItem('isAuthenticated');
        setIsAuthenticated(false); // Update state
        navigate('/login', { replace: true });
    };

    return (
        <div>
            <Navbar>
                <NavbarBrand href="/">Dashboard</NavbarBrand>
                {!isMobile && (
                    <NavbarMenu>
                        <NavList style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                            <div style={{ display: 'flex' }}>
                                <NavItem>
                                    <NavLink className="dropdown-toggle" onClick={toggleVendas}>
                                        Vendas
                                    </NavLink>
                                    {isVendasOpen && (
                                        <DropdownMenu>
                                            <DropdownItem onClick={() => handleNavigation('/Departamento')}>
                                                Vendas por departamento
                                            </DropdownItem>
                                            <DropdownItem onClick={() => handleNavigation('/VendasOnline')}>
                                                Vendas Online
                                            </DropdownItem>
                                            <DropdownItem onClick={() => handleNavigation('/Finalizadoras')}>
                                                Finalizadoras
                                            </DropdownItem>
                                        </DropdownMenu>
                                    )}
                                </NavItem>

                                <NavItem>
                                    <NavLink className="dropdown-toggle" onClick={toggleDespesas}>
                                        Despesas
                                    </NavLink>
                                    {isDespesasOpen && (
                                        <DropdownMenu>
                                            <DropdownItem onClick={() => handleNavigation('/despesas/detalhes')}>
                                               EM BREVE
                                            </DropdownItem>
                                            <DropdownItem onClick={() => handleNavigation('/despesas/relatorio')}>
                                               EM BREVE
                                            </DropdownItem>
                                        </DropdownMenu>
                                    )}
                                </NavItem>
                            </div>

                            <NavItem>
                                <NavLink onClick={handleLogout} style={{ marginLeft: 'auto' }}>
                                    <FaSignOutAlt /> Sair
                                </NavLink>
                            </NavItem>
                        </NavList>
                    </NavbarMenu>
                )}
                {isMobile && (
                    <Hamburger onClick={toggleMenu}>
                        <span></span>
                        <span></span>
                        <span></span>
                    </Hamburger>
                )}
            </Navbar>

            {isMobile && (
                <AsideMenu $isOpen={isMenuOpen}>
                    <CloseButton onClick={toggleMenu}>×</CloseButton>
                    <NavList>
                        <NavItem>
                            <NavLink className="dropdown-toggle" onClick={toggleVendas}>
                                Vendas
                            </NavLink>
                            {isVendasOpen && (
                                <SubNavList>
                                    <SubNavItem>
                                        <SubNavLink onClick={() => handleNavigation('/Departamento')}>
                                            Vendas por departamento
                                        </SubNavLink>
                                    </SubNavItem>
                                    <SubNavItem>
                                        <SubNavLink onClick={() => handleNavigation('/VendasOnline')}>
                                            Vendas Online
                                        </SubNavLink>
                                        <SubNavLink onClick={() => handleNavigation('/Finalizadoras')}>
                                            Finalizadoras
                                        </SubNavLink>
                                    </SubNavItem>
                                </SubNavList>
                            )}
                        </NavItem>

                        <NavItem>
                            <NavLink className="dropdown-toggle" onClick={toggleDespesas}>
                                Despesas
                            </NavLink>
                            {isDespesasOpen && (
                                <SubNavList>
                                    <SubNavItem>
                                        <SubNavLink onClick={() => handleNavigation('/despesas/detalhes')}>
                                            EM BREVE
                                        </SubNavLink>
                                    </SubNavItem>
                                    <SubNavItem>
                                        <SubNavLink onClick={() => handleNavigation('/despesas/relatorio')}>
                                            EM BREVE
                                        </SubNavLink>
                                    </SubNavItem>
                                </SubNavList>
                            )}
                        </NavItem>

                        <NavItem>
                            <NavLink onClick={handleLogout}>
                                <FaSignOutAlt /> Sair
                            </NavLink>
                        </NavItem>
                    </NavList>
                </AsideMenu>
            )}
        </div>
    );
};

export default Header;
