import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Particles from 'react-tsparticles';
import { loadFull } from 'tsparticles';
import {
    Container,
    FormContainer,
    Title,
    Input,
    Button,
    Footer,
    ErrorMessage
} from './styles'; // Assuming styles.js contains the shared styles
import { loadConfig } from '../../api/apiConfig';

const Login = ({ setIsAuthenticated }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        setError('');
        
        if (!username || !password) {
            setError('Please enter both username and password.');
            return;
        }

        setLoading(true);

        try {
            const apiUrl = await loadConfig();
            const response = await fetch(`${apiUrl}/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password }),
            });

            const result = await response.json();

            if (response.ok && result.success) {
                localStorage.setItem('isAuthenticated', 'true');
                setIsAuthenticated(true);
                navigate('/');
            } else {
                setError(result.message || 'Incorrect username or password.');
            }
        } catch (error) {
            setError('An error occurred. Please try again later.',error);
        } finally {
            setLoading(false);
        }
    };

    const particlesInit = useCallback(async (engine) => {
        await loadFull(engine);
    }, []);

    return (
        <Container>
            <Particles
                id="tsparticles"
                init={particlesInit}
                options={{
                    background: {
                        color: { value: "#102C57" },
                    },
                    fpsLimit: 60,
                    particles: {
                        color: { value: "#ffffff" },
                        move: {
                            direction: "none",
                            enable: true,
                            outMode: "bounce",
                            speed: 2,
                            random: true,
                            straight: false,
                        },
                        number: {
                            density: { enable: true, area: 800 },
                            value: 100,
                        },
                        opacity: { value: 0.6 },
                        shape: { type: "circle", stroke: { width: 2, color: "#ffffff" } },
                        size: { random: true, value: 7 },
                        links: { enable: true, distance: 150, color: "#ffffff", opacity: 0.4, width: 1 },
                    },
                }}
            />
            <FormContainer onSubmit={handleLogin}>
                <Title>Dashboard</Title>
                {error && <ErrorMessage>{error}</ErrorMessage>}
                <Input
                    type="text"
                    id="username"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                />
                <Input
                    type="password"
                    id="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <Button type="submit" disabled={loading}>
                    {loading ? 'Logging in...' : 'Login'}
                </Button>
                <Button type="button" onClick={() => navigate('/register')}>
                    Register
                </Button>
                <Footer>Developed by Tiago Henrique Zocatelli</Footer>
            </FormContainer>
        </Container>
    );
};

export default Login;
