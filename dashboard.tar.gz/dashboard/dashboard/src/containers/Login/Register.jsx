import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Particles from 'react-tsparticles';
import { loadFull } from 'tsparticles';
import {
    Container,
    FormContainer,
    Title,
    Input,
    Button,
    Footer,
    ErrorMessage
} from './styles';
import { loadConfig } from '../../api/apiConfig';

const Register = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [isVerified, setIsVerified] = useState(false);
    const [initialUsername, setInitialUsername] = useState('');
    const [initialPassword, setInitialPassword] = useState('');
    const navigate = useNavigate();

    const handleVerification = (e) => {
        e.preventDefault();
        if (initialUsername === 'dash' && initialPassword === 'Dash159951') {
            setIsVerified(true);
            setError('');
        } else {
            setError('Incorrect initial username or password.');
        }
    };

    const handleRegister = async (e) => {
        e.preventDefault();
        setError('');

        if (!username || !password) {
            setError('Please enter both username and password.');
            return;
        }

        setLoading(true);

        try {
            const apiUrl = await loadConfig();
            const response = await fetch(`${apiUrl}/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password }),
            });

            const result = await response.json();

            if (response.ok && result.success) {
                alert(result.message);
                navigate('/login');
            } else {
                setError(result.message || 'Registration failed.');
            }
        } catch (error) {
            setError('An error occurred. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    const particlesInit = useCallback(async (engine) => {
        await loadFull(engine);
    }, []);

    return (
        <Container>
            <Particles
                id="tsparticles"
                init={particlesInit}
                options={{
                    background: {
                        color: { value: "#102C57" },
                    },
                    fpsLimit: 60,
                    particles: {
                        color: { value: "#ffffff" },
                        move: {
                            direction: "none",
                            enable: true,
                            outMode: "bounce",
                            speed: 2,
                            random: true,
                            straight: false,
                        },
                        number: {
                            density: { enable: true, area: 800 },
                            value: 100,
                        },
                        opacity: { value: 0.6 },
                        shape: { type: "circle", stroke: { width: 2, color: "#ffffff" } },
                        size: { random: true, value: 7 },
                        links: { enable: true, distance: 150, color: "#ffffff", opacity: 0.4, width: 1 },
                    },
                }}
            />
            {!isVerified ? (
                <FormContainer onSubmit={handleVerification}>
                    <Title>Initial Verification</Title>
                    {error && <ErrorMessage>{error}</ErrorMessage>}
                    <Input
                        type="text"
                        placeholder="Initial Username"
                        value={initialUsername}
                        onChange={(e) => setInitialUsername(e.target.value)}
                        required
                    />
                    <Input
                        type="password"
                        placeholder="Initial Password"
                        value={initialPassword}
                        onChange={(e) => setInitialPassword(e.target.value)}
                        required
                    />
                    <Button type="submit">Verify</Button>
                    <Button type="button" onClick={() => navigate('/login')}>
                        Voltar para Login
                    </Button>
                </FormContainer>
            ) : (
                <FormContainer onSubmit={handleRegister}>
                    <Title>Register</Title>
                    {error && <ErrorMessage>{error}</ErrorMessage>}
                    <Input
                        type="text"
                        id="username"
                        placeholder="Username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                    />
                    <Input
                        type="password"
                        id="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <Button type="submit" disabled={loading}>
                        {loading ? 'Registering...' : 'Register'}
                    </Button>
                    <Button type="button" onClick={() => navigate('/login')}>
                        Voltar para Login
                    </Button>
                    <Footer>Developed by Tiago Henrique Zocatelli</Footer>
                </FormContainer>
            )}
        </Container>
    );
};

export default Register;
