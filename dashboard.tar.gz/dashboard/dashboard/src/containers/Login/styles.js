import styled, { keyframes } from 'styled-components';

// Keyframes for the animated gradient background and floating particles
const moveShapes = keyframes`
    0% { transform: translateY(0) translateX(0); }
    50% { transform: translateY(-30px) translateX(30px); }
    100% { transform: translateY(0) translateX(0); }
`;

export const Container = styled.div`
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    overflow: hidden;
    background: linear-gradient(135deg, #102C57, #345585);
`;

export const FormContainer = styled.form`
    position: relative;  /* Ensure form is on top */
    z-index: 10;  /* High z-index to place the form above the particles */
    background: rgba(255, 255, 255, 0.95);
    padding: 50px;
    border-radius: 20px;
    box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.2);
    max-width: 400px;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    backdrop-filter: blur(10px);
    transition: transform 0.3s ease, box-shadow 0.3s ease;

    &:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.25);
    }
`;

export const Title = styled.h2`
    font-size: 26px;
    color: #102C57;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 2px;
    text-align: center;
`;

export const Input = styled.input`
    width: 100%;
    padding: 15px;
    margin-bottom: 25px;
    border-radius: 30px;
    border: 1px solid #ddd;
    font-size: 16px;
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: border-color 0.3s ease, box-shadow 0.3s ease;

    &:focus {
        border-color: #345585;
        outline: none;
        box-shadow: 0 0 10px rgba(52, 85, 133, 0.4);
    }
`;

export const Button = styled.button`
    width: 100%;
    padding: 15px;
    border-radius: 30px;
    border: none;
    background-color: #345585;
    color: #fff;
    font-size: 18px;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
    margin-top: 10px;

    &:hover {
        background-color: #284A7D;
        transform: translateY(-3px);
        box-shadow: 0 10px 20px rgba(40, 74, 125, 0.3);
    }

    &:active {
        transform: translateY(1px);
    }

    &:disabled {
        background-color: #aaa;
        cursor: not-allowed;
    }
`;

export const Footer = styled.p`
    margin-top: 30px;
    font-size: 14px;
    color: #666;
    text-align: center;
    letter-spacing: 1px;
`;

export const ErrorMessage = styled.div`
    color: #ff4d4d;
    margin-bottom: 20px;
    font-size: 15px;
    text-align: center;
    background: #ffeeee;
    padding: 10px;
    border-radius: 10px;
    border: 1px solid #ffdddd;
`;
