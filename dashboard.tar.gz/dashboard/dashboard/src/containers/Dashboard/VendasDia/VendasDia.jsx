import { useState, useEffect } from "react";
import {
  Title,
  FilialSelector,
  CardGrid,
  Card,
  CardTitle,
  CardContent,
  NoDataMessage,
} from "./VendasDiaStyles";
import {
  FaUsers,
  FaShoppingCart,
  FaDollarSign,
  FaPercentage,
  FaCalendarDay,
} from "react-icons/fa";
import { ChartWrapper, MonthSelector } from "../VendasMes/styles";

// eslint-disable-next-line react/prop-types
const VendasDia = ({ vendasDia }) => {
  const [selectedFilial, setSelectedFilial] = useState("");
  const [selectedMonth, setSelectedMonth] = useState("");
  const [dailyData, setDailyData] = useState([]);

  useEffect(() => {
    if (vendasDia && !selectedFilial) {
      const firstFilial = Object.keys(vendasDia)[0];
      setSelectedFilial(firstFilial);
    }
  }, [vendasDia, selectedFilial]);

  useEffect(() => {
    if (vendasDia && selectedFilial) {
      const filteredData = selectedMonth
        // eslint-disable-next-line react/prop-types
        ? vendasDia[selectedFilial].filter((item) =>
            item.dia.startsWith(selectedMonth)
          )
        : vendasDia[selectedFilial];
      setDailyData(filteredData);
    }
  }, [vendasDia, selectedFilial, selectedMonth]);

  const handleFilialChange = (event) => {
    setSelectedFilial(event.target.value);
  };

  const handleMonthChange = (event) => {
    setSelectedMonth(event.target.value);
  };

  return (
    <ChartWrapper>
      <Title>Vendas Diárias</Title>
      <FilialSelector
        onChange={handleFilialChange}
        value={selectedFilial || ""}
      >
        <option value="">Selecione uma Filial</option>
        {Object.keys(vendasDia || {}).map((filial) => (
          <option key={filial} value={filial}>
            Filial {filial}
          </option>
        ))}
      </FilialSelector>

      {selectedFilial && (
        <MonthSelector onChange={handleMonthChange} value={selectedMonth || ""}>
          <option value="">Todos os Meses</option>
          {Array.from(
            new Set(
              // eslint-disable-next-line react/prop-types
              vendasDia[selectedFilial].map((item) => item.dia.slice(0, 7))
            )
          ).map((month) => (
            <option key={month} value={month}>
              {month}
            </option>
          ))}
        </MonthSelector>
      )}

      {selectedFilial && dailyData.length > 0 ? (
        <CardGrid>
          {dailyData.map((item) => (
            <Card key={item.dia}>
              <CardTitle>
                <FaCalendarDay /> {item.dia}
              </CardTitle>
              <CardContent>
                <FaUsers /> Clientes: {item.nclientes}
              </CardContent>
              <CardContent>
                <FaShoppingCart /> Produtos: {item.totprodvda}
              </CardContent>
              <CardContent>
                <FaDollarSign /> Custos: R${" "}
                {parseFloat(item.totvrcusto).toLocaleString("pt-BR", {
                  minimumFractionDigits: 2,
                })}
              </CardContent>
              <CardContent>
                <FaDollarSign /> Vendas: R${" "}
                {parseFloat(item.totvrvenda).toLocaleString("pt-BR", {
                  minimumFractionDigits: 2,
                })}
              </CardContent>
              <CardContent>
                <FaPercentage /> Ticket Médio: R${" "}
                {parseFloat(item.totvrvenda / item.nclientes).toLocaleString(
                  "pt-BR",
                  { minimumFractionDigits: 2 }
                )}
              </CardContent>
              <CardContent>
                <FaDollarSign /> Lucro: R${" "}
                {parseFloat(item.totvrvenda - item.totvrcusto).toLocaleString(
                  "pt-BR",
                  { minimumFractionDigits: 2 }
                )}
              </CardContent>
            </Card>
          ))}
        </CardGrid>
      ) : (
        <NoDataMessage>
          Selecione uma filial para ver os dados diários.
        </NoDataMessage>
      )}
    </ChartWrapper>
  );
};

export default VendasDia;
