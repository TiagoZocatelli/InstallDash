import styled from 'styled-components';

export const VendasDiaWrapper = styled.div`
    margin-top: 20px;
    font-family: 'Roboto', sans-serif; /* Fonte mais moderna e profissional */
`;

export const Title = styled.h3`
    color: #34495e;
    font-size: 26px;
    margin-bottom: 20px;
    text-align: center;
    font-weight: 600;
`;

export const FilialSelector = styled.select`
    padding: 12px;
    font-size: 16px;
    margin-bottom: 20px;
    border: 1px solid #34495e;
    border-radius: 8px;
    background-color: #ecf0f1;
    color: #34495e;
    outline: none;
    transition: border-color 0.3s, box-shadow 0.3s;

    &:focus {
        border-color: #2980b9;
        box-shadow: 0 0 8px rgba(41, 128, 185, 0.3);
    }
`;

export const CardGrid = styled.div`
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); /* Cards maiores para uniformidade */
    gap: 20px;
    max-height: 500px;
    overflow-y: auto;
    padding-right: 10px;
    margin-top: 20px;

    &::-webkit-scrollbar {
        width: 8px;
    }

    &::-webkit-scrollbar-thumb {
        background-color: #2980b9;
        border-radius: 4px;
    }

    &::-webkit-scrollbar-track {
        background-color: #ecf0f1;
    }
`;

export const Card = styled.div`
    background-color: #102C57;
    font-weight: bold;
    border-radius: 12px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
    padding: 20px;
    text-align: center;
    color: #fff;
    transition: transform 0.3s, box-shadow 0.3s;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    min-height: 200px; /* Garantir que todos os cards tenham a mesma altura */

    &:hover {
        transform: translateY(-5px);
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.25);
    }
`;

export const CardTitle = styled.h4`
    color: #f39c12;
    margin-bottom: 10px;
    font-size: 20px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;

    & > svg {
        margin-right: 8px;
    }
`;

export const CardContent = styled.p`
    margin: 8px 0;
    font-size: 16px;
    color: #ecf0f1;
    display: flex;
    align-items: center;
    justify-content: center;

    & > svg {
        margin-right: 8px;
    }
`;

export const NoDataMessage = styled.p`
    margin-top: 20px;
    color: #95a5a6;
    font-size: 16px;
    text-align: center;
`;
