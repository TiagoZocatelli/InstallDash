import styled from 'styled-components';

export const Container = styled.div`
    max-width: 1400px;
    margin: 0 auto;
    padding: 25px;
    background-color: #ffffff; /* Fundo branco para contraste */
    border-radius: 12px;
    box-shadow: 0 4px 8px rgba(16, 44, 87, 0.2);
    transition: box-shadow 0.2s ease-in-out;

    &:hover {
        box-shadow: 0 6px 12px rgba(16, 44, 87, 0.25);
    }

    @media (max-width: 768px) {
        padding: 20px;
    }
`;

export const Title = styled.h1`
    font-size: 2.2rem;
    color: #102C57; /* Azul profundo */
    text-align: center;
    margin-bottom: 20px;
    font-weight: 600;
    transition: color 0.2s ease-in-out;

    &:hover {
        color: #2a9d8f; /* Verde suave para destaque */
    }

    @media (max-width: 768px) {
        font-size: 1.8rem;
        margin-bottom: 15px;
    }
`;

export const ChartWrapper = styled.div`
    margin-top: 25px;
    background-color: #f4f4f9; /* Tom suave de cinza para contraste */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 3px 6px rgba(16, 44, 87, 0.1);
    transition: box-shadow 0.2s ease-in-out;

    &:hover {
        box-shadow: 0 5px 10px rgba(16, 44, 87, 0.15);
    }

    @media (max-width: 768px) {
        padding: 15px;
        margin-top: 15px;
    }
`;



export const List = styled.ul`
    list-style-type: none;
    padding: 0;
    margin: 0;

    @media (max-width: 768px) {
        padding: 0;
        margin: 0;
    }
`;

export const ListItem = styled.li`
    padding: 10px;
    background-color: #e9ecef; /* Fundo claro com leve tom azul */
    margin-bottom: 8px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(16, 44, 87, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: background-color 0.2s ease-in-out;

    &:last-child {
        margin-bottom: 0;
    }

    &:hover {
        background-color: #e9ecef; /* Fundo mais escuro ao hover */
        color: #ffffff; /* Texto branco ao hover */
    }

    @media (max-width: 768px) {
        padding: 8px;
        flex-direction: column;
        align-items: flex-start;
        margin-bottom: 6px;
    }
`;

export const ListItemLabel = styled.span`
    font-weight: 600;
    color: #102C57; /* Azul profundo */
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    transition: color 0.2s ease-in-out;

    &:hover {
        color: #2a9d8f; /* Verde suave para destaque */
    }

    @media (max-width: 768px) {
        font-size: 1rem;
        margin-bottom: 5px;
    }
`;

export const ListItemValue = styled.span`
    font-size: 1.2rem;
    color: #495057; /* Cinza para textos */
    transition: color 0.2s ease-in-out;

    &:hover {
        color: #264653; /* Azul escuro ao hover */
    }

    @media (max-width: 768px) {
        font-size: 1rem;
    }
`;

export const FilterContainer = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding: 15px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 3px 6px rgba(16, 44, 87, 0.1);
    transition: box-shadow 0.2s ease-in-out;

    &:hover {
        box-shadow: 0 5px 10px rgba(16, 44, 87, 0.15);
    }

    & > *:not(:last-child) {
        margin-right: 15px;
    }

    @media (max-width: 768px) {
        flex-direction: column;
        align-items: flex-start;
        padding: 10px;
        margin-bottom: 15px;

        & > *:not(:last-child) {
            margin-right: 0;
            margin-bottom: 10px;
        }
    }
`;

export const Label = styled.label`
    font-size: 1rem;
    color: #102C57; /* Azul profundo para consistência */
    font-weight: 500;

    @media (max-width: 768px) {
        font-size: 0.9rem;
    }
`;

export const DateInput = styled.input`
    padding: 8px 12px;
    font-size: 1rem;
    border: 1px solid #ced4da;
    border-radius: 8px;
    background-color: #ffffff;
    color: #102C57; /* Azul profundo */
    transition: border-color 0.2s ease-in-out;

    &:focus {
        border-color: #102C57; /* Azul profundo */
        box-shadow: 0 0 0 4px rgba(16, 44, 87, 0.1);
        outline: none;
    }

    @media (max-width: 768px) {
        padding: 6px 10px;
        font-size: 0.9rem;
    }
`;

export const SearchButton = styled.button`
    padding: 8px 16px;
    font-size: 1rem;
    color: #ffffff;
    background-color: #102C57; /* Azul profundo */
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.2s ease-in-out;

    &:hover {
        background-color: #0d1a38; /* Azul um pouco mais escuro ao hover */
    }

    &:active {
        transform: translateY(0);
    }

    @media (max-width: 768px) {
        padding: 6px 12px;
        font-size: 0.9rem;
    }
`;

export const Select = styled.select`
    padding: 8px 12px;
    font-size: 1rem;
    border: 1px solid #ced4da;
    border-radius: 8px;
    background-color: #ffffff;
    color: #102C57; /* Azul profundo */
    transition: border-color 0.2s ease-in-out;

    &:focus {
        border-color: #102C57; /* Azul profundo */
        box-shadow: 0 0 0 4px rgba(16, 44, 87, 0.1);
        outline: none;
    }

    @media (max-width: 768px) {
        padding: 6px 10px;
        font-size: 0.9rem;
    }
`;

export const Option = styled.option`
    font-size: 1rem;
    color: #102C57; /* Azul profundo */
    background-color: #ffffff;
    padding: 8px;
    transition: background-color 0.2s ease-in-out;

    &:hover {
        background-color: #e9ecef; /* Fundo mais claro ao hover */
    }

    @media (max-width: 768px) {
        font-size: 0.9rem;
    }
`;
