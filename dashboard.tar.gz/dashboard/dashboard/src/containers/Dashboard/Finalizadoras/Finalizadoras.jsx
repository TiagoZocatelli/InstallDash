import { useState, useEffect } from "react";
import Chart from "react-apexcharts";
import { fetchFinalizadoraData } from "../../../api/API-FIN";
import {
  Container,
  Title,
  ChartWrapper,
  List,
  ListItem,
  ListItemLabel,
  ListItemValue,
  FilterContainer,
  Label,
  DateInput,
  SearchButton,
  Select,
  Option,
} from "./styles";

const FinalizadorasPeriodo = () => {
  const defaultStartDate = new Date();
  defaultStartDate.setMonth(defaultStartDate.getMonth() - 1); // Default to one month ago
  const defaultEndDate = new Date();
  
  const [finalizadoras, setFinalizadoras] = useState({});
  const [pdvs, setPdvs] = useState({});
  const [filiais, setFiliais] = useState([]); // State to hold fetched filiais
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [startDate, setStartDate] = useState(defaultStartDate.toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(defaultEndDate.toISOString().split('T')[0]);
  const [filial, setFilial] = useState("");

  useEffect(() => {
    const loadFinalizadorasData = async () => {
      try {
        const data = await fetchFinalizadoraData(startDate, endDate, filial);
        setFinalizadoras(data.finalizadoras);
        setPdvs(data.pdvs);

        // Extract filial keys from the pdvs object
        const filialKeys = Object.keys(data.pdvs);
        setFiliais(filialKeys);

        setLoading(false);
      } catch (error) {
        console.error("Erro ao buscar dados:", error);
        setError("Failed to load data");
        setLoading(false);
      }
    };

    // Load data with default values initially
    loadFinalizadorasData();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSearch = () => {
    setLoading(true);
    fetchFinalizadoraData(startDate, endDate, filial)
      .then((data) => {
        setFinalizadoras(data.finalizadoras);
        setPdvs(data.pdvs);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Erro ao buscar dados:", error);
        setError("Failed to load data");
        setLoading(false);
      });
  };

  const calculateTotalsAndPercentages = (data) => {
    let filteredData = data;

    if (filial) {
      filteredData = Object.keys(pdvs[filial] || {}).reduce((acc, pdv) => {
        const pdvData = pdvs[filial][pdv];
        Object.keys(pdvData).forEach((finalizadora) => {
          acc[finalizadora] = (acc[finalizadora] || 0) + pdvData[finalizadora];
        });
        return acc;
      }, {});
    }

    const total = Object.values(filteredData).reduce(
      (sum, value) => sum + value,
      0
    );
    return Object.entries(filteredData).map(([key, value]) => ({
      name: key,
      value: parseFloat(value),
      percentage: total > 0 ? ((value / total) * 100).toFixed(2) : 0,
    }));
  };

  const calculatePdvsData = (pdvs) => {
    const pdvSales = {};

    Object.entries(pdvs).forEach(([filialKey, pdvsData]) => {
      if (!filial || filial === filialKey) {
        Object.entries(pdvsData).forEach(([pdv, salesData]) => {
          const pdvTotal = Object.values(salesData).reduce(
            (sum, value) => sum + value,
            0
          );
          pdvSales[pdv] = (pdvSales[pdv] || 0) + pdvTotal;
        });
      }
    });

    const totalSales = Object.values(pdvSales).reduce(
      (sum, value) => sum + value,
      0
    );

    const sortedPdvs = Object.entries(pdvSales)
      .map(([pdv, total]) => ({
        pdv,
        total,
        percentage:
          totalSales > 0 ? ((total / totalSales) * 100).toFixed(2) : 0,
      }))
      .sort((a, b) => parseInt(a.pdv) - parseInt(b.pdv)); // Sort PDVs numerically

    return sortedPdvs;
  };

  const finalizadoraData = calculateTotalsAndPercentages(finalizadoras);
  const finalizadoraChartData = finalizadoraData.map((item) => item.value);
  const finalizadoraChartLabels = finalizadoraData.map((item) => item.name);

  const pdvData = calculatePdvsData(pdvs);
  const pdvChartData = pdvData.map((item) => item.total);
  const pdvChartLabels = pdvData.map((item) => `PDV ${item.pdv}`);
  const pdvChartPercentages = pdvData.map((item) => item.percentage);

  const finalizadoraChartOptions = {
    chart: {
      type: "pie",
    },
    labels: finalizadoraChartLabels,
    plotOptions: {
      pie: {
        donut: {
          size: "50%",
        },
      },
    },
    dataLabels: {
      enabled: true,
      formatter: function (val) {
        return `${val.toFixed(2)}%`;
      },
    },
    legend: {
      position: "bottom",
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return `R$ ${val.toLocaleString("pt-BR", {
            minimumFractionDigits: 2,
          })}`;
        },
      },
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          chart: {
            width: 300,
          },
          legend: {
            position: "bottom",
          },
        },
      },
    ],
  };

  const pdvChartOptions = {
    chart: {
      type: "bar",
      toolbar: {
        show: false,
      },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: "70%",
        endingShape: "rounded",
        dataLabels: {
          position: "top",
        },
      },
    },
    colors: ["#FF4560", "#00E396", "#008FFB", "#FEB019", "#775DD0"],
    dataLabels: {
      enabled: true,
      offsetY: -20,
      style: {
        fontSize: "12px",
        colors: ["#000000"],
      },
      formatter: function (val, opts) {
        const percentage = pdvChartPercentages[opts.dataPointIndex];
        return `${parseFloat(percentage).toFixed(2)}%`;
      },
    },
    xaxis: {
      categories: pdvChartLabels,
      labels: {
        rotate: -45,
        style: {
          fontSize: "12px",
          colors: ["#304758"],
        },
      },
    },
    yaxis: {
      labels: {
        style: {
          fontSize: "12px",
          colors: ["#304758"],
        },
        formatter: function (val) {
          return val.toLocaleString("pt-BR", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          });
        },
      },
    },
    grid: {
      show: true,
      borderColor: "#f1f1f1",
    },
    tooltip: {
      y: {
        formatter: function (val, opts) {
          const percentage = pdvChartPercentages[opts.dataPointIndex];
          return `R$ ${val.toLocaleString("pt-BR", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })} (${parseFloat(percentage).toFixed(2)}%)`;
        },
      },
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          chart: {
            width: "100%",
            height: 320,
          },
          plotOptions: {
            bar: {
              columnWidth: "50%",
            },
          },
          xaxis: {
            labels: {
              rotate: 0,
            },
          },
        },
      },
    ],
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  return (
    <Container>
      <Title>Finalizadoras por Período</Title>

      <FilterContainer>
        <Label htmlFor="startDate">Data Inicial:</Label>
        <DateInput
          id="startDate"
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
        />
        <Label htmlFor="endDate">Data Final:</Label>
        <DateInput
          id="endDate"
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />
        <Label htmlFor="filial">Filial:</Label>
        <Select
          id="filial"
          value={filial}
          onChange={(e) => setFilial(e.target.value)}
        >
          <Option value="">Todas</Option>
          {filiais.map((filialKey) => (
            <Option key={filialKey} value={filialKey}>
              Filial {filialKey}
            </Option>
          ))}
        </Select>
        <SearchButton onClick={handleSearch}>Pesquisar</SearchButton>
      </FilterContainer>

      <ChartWrapper>
        <h2>Ranking de Finalizadoras</h2>
        <Chart
          options={finalizadoraChartOptions}
          series={finalizadoraChartData}
          type="pie"
          height={400}
        />
      </ChartWrapper>

      <ChartWrapper>
        <h2>Total por Finalizadora</h2>
        <List>
          {finalizadoraData.map(({ name, value }) => (
            <ListItem key={name}>
              <ListItemLabel>{name}:</ListItemLabel>
              <ListItemValue>
                R${" "}
                {parseFloat(value).toLocaleString("pt-BR", {
                  minimumFractionDigits: 2,
                })}
              </ListItemValue>
            </ListItem>
          ))}
        </List>
      </ChartWrapper>

      {filial && (
        <ChartWrapper>
          <h2>Ranking de PDVs</h2>
          <Chart
            options={pdvChartOptions}
            series={[{ data: pdvChartData }]}
            type="bar"
            height={400}
          />
        </ChartWrapper>
      )}
    </Container>
  );
};

export default FinalizadorasPeriodo;
