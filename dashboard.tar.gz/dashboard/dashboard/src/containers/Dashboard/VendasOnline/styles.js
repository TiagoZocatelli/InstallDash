import styled from "styled-components";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export const ChartContainer = styled.div`
  width: 100%;
  max-width: 1600px;
  margin: 20px auto;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
`;

export const Container = styled.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 30px;
  background-color: #f5f7fa;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
`;

export const Title = styled.h1`
  font-size: 26px;
  color: #1c3d5a;
  text-align: center;
  margin-bottom: 25px;
  font-weight: 700;
`;

export const FilterContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
  padding: 15px;
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);

  & > *:not(:last-child) {
    margin-right: 15px;
  }

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: flex-start;
    padding: 10px;
    margin-bottom: 20px;

    & > *:not(:last-child) {
      margin-right: 0;
      margin-bottom: 10px;
    }
  }
`;

export const Label = styled.label`
  font-size: 1rem;
  color: #1c3d5a;
  font-weight: 500;

  @media (max-width: 768px) {
    font-size: 0.9rem;
  }
`;

export const Select = styled.select`
  padding: 8px 12px;
  font-size: 1rem;
  border: 1px solid #a0a4a8;
  border-radius: 6px;
  background-color: #ffffff;
  color: #1c3d5a;
  transition: border-color 0.3s;

  &:focus {
    border-color: #1c3d5a;
    outline: none;
  }

  @media (max-width: 768px) {
    padding: 6px 10px;
    font-size: 0.9rem;
  }
`;

export const Option = styled.option`
  font-size: 1rem;
  color: #1c3d5a;
  background-color: #ffffff;
  padding: 8px;

  &:hover {
    background-color: #f5f7fa;
  }

  @media (max-width: 768px) {
    font-size: 0.9rem;
  }
`;

export const ChartWrapper = styled.div`
  margin-top: 25px;

  @media (max-width: 768px) {
    margin-top: 15px;
  }
`;

export const List = styled.ul`
  list-style-type: none;
  padding: 0;
  margin: 0;

  @media (max-width: 768px) {
    padding: 0;
    margin: 0;
  }
`;

export const ListItem = styled.li`
  padding: 12px 15px;
  background: linear-gradient(135deg, #ffffff, #f0f4f7);
  margin-bottom: 10px;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: transform 0.3s, box-shadow 0.3s;

  &:last-child {
    margin-bottom: 0;
  }

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }

  @media (max-width: 768px) {
    padding: 10px;
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 8px;
  }
`;

export const ListItemLabel = styled.span`
  font-weight: 600;
  color: #1c3d5a;
  font-size: 1.2rem;
  display: flex;
  align-items: center;

  @media (max-width: 768px) {
    font-size: 1.1rem;
    margin-bottom: 5px;
  }
`;

export const Icon = styled(FontAwesomeIcon)`
  margin-right: 10px;
  color: #1c3d5a;
  font-size: 1.4rem;
`;

export const ListItemValue = styled.span`
  font-size: 1.3rem;
  color: #495057;

  @media (max-width: 768px) {
    font-size: 1.1rem;
  }
`;

export const SectionTitle = styled.h2`
  font-size: 1.8rem;
  color: #1c3d5a;
  margin-top: 25px;
  margin-bottom: 15px;
  text-align: left;
  font-weight: 600;

  @media (max-width: 768px) {
    font-size: 1.5rem;
    margin-top: 20px;
    margin-bottom: 10px;
  }
`;

export const Section = styled.section`
  margin-top: 30px;

  @media (max-width: 768px) {
    margin-top: 20px;
  }
`;

export const PDVContainer = styled.div`
    display: flex;
    flex-wrap: wrap;
    gap: 20px;

    @media (max-width: 768px) {
        flex-direction: column;
        gap: 15px;
    }
`;

export const PDVDetails = styled.div`
    flex: 1 1 320px;
    max-width: 320px;
    background: #ffffff; 
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
    border: 1px solid #e0e0e0;
    overflow-y: auto;
    transition: transform 0.3s, box-shadow 0.3s;

    &:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
    }

    @media (max-width: 768px) {
        padding: 15px;
    }
`;

export const PDVTitle = styled.h4`
    font-size: 1.5rem;
    color: #1c3d5a;
    margin-bottom: 15px;
    font-weight: 600;
    text-align: center;

    @media (max-width: 768px) {
        font-size: 1.3rem;
        margin-bottom: 10px;
    }
`;

export const Button = styled.button`
  margin-top: 20px;
  padding: 10px 20px;
  font-size: 1.1rem;
  color: #ffffff;
  background-color: #1c3d5a;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s, transform 0.3s;

  &:hover {
    background-color: #102c57;
    transform: translateY(-2px);
  }

  @media (max-width: 768px) {
    padding: 8px 16px;
    font-size: 1rem;
    margin-top: 15px;
  }
`;

export const TotalValueContainer = styled.div`
  margin-top: 20px;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;

  @media (max-width: 768px) {
    padding: 15px;
    flex-direction: column;
    align-items: flex-start;
    margin-top: 15px;
  }
`;

export const TotalValueLabel = styled.span`
  font-size: 1.3rem;
  color: #1c3d5a;
  font-weight: 600;

  @media (max-width: 768px) {
    font-size: 1.2rem;
    margin-bottom: 10px;
  }
`;

export const TotalValue = styled.span`
  font-size: 1.6rem;
  color: #27ae60;
  font-weight: 700;

  @media (max-width: 768px) {
    font-size: 1.4rem;
  }
`;

export const MaxPDVContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;

  @media (max-width: 768px) {
    gap: 15px;
  }
`;

export const MaxPDVLabel = styled.span`
  font-size: 1.2rem;
  color: #1c3d5a;
  font-weight: 600;
  display: inline-block;
  margin-right: 10px;

  @media (max-width: 768px) {
    font-size: 1rem;
  }
`;

export const MaxPDVValue = styled.span`
  font-size: 1.4rem;
  color: #e74c3c;
  font-weight: 700;
  display: inline-block;
  margin-left: 10px;

  @media (max-width: 768px) {
    font-size: 1.2rem;
  }
`;

export const PercentageLabel = styled.span`
  font-size: 1.2rem;
  color: #1c3d5a;
  font-weight: 500;
  display: inline-block;
  margin-right: 10px;

  @media (max-width: 768px) {
    font-size: 1rem;
  }
`;

export const PieChartWrapper = styled.div`
  margin: 0 auto;
  width: 100%;
  max-width: 600px;
`;
