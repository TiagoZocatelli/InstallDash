import { useState, useEffect } from 'react';
import Chart from 'react-apexcharts';
import { fetchOnlineData } from '../../../api/API-ON';
import { faCreditCard, faMoneyBill, faCashRegister } from '@fortawesome/free-solid-svg-icons';
import {
    Container,
    Title,
    FilterContainer,
    Label,
    Select,
    PieChartWrapper,
    List,
    ListItem,
    ListItemLabel,
    Icon,
    ListItemValue,
    SectionTitle,
    Section,
    Option,
    PDVDetails,
    PDVContainer,
    PDVTitle,
    Button,
    TotalValueContainer,
    TotalValueLabel,
    TotalValue,
    ChartContainer
} from './styles'; // Ajuste o caminho conforme necessário

const FinalizadorasOnline = () => {
    const [finalizadoras, setFinalizadoras] = useState({});
    const [pdvsOnline, setPdvsOnline] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedFilial, setSelectedFilial] = useState('All'); // Para filtro por filial
    const [selectedPDV, setSelectedPDV] = useState('All');
    const [pieChartData, setPieChartData] = useState({ series: [], labels: [] });
    const [pdvChartData, setPdvChartData] = useState({ series: [], labels: [] }); // Novo estado para o gráfico de PDVs
    const [totalFinalizadorasValue, setTotalFinalizadorasValue] = useState(0); // Estado para o valor total
    const [showPDVDetails, setShowPDVDetails] = useState(false); // Alternar detalhes do PDV
    const [totalPorFinalizadora, setTotalPorFinalizadora] = useState({}); // Estado para total por finalizadora

    // Mapeamento dos ícones para tipos de "especie"
    const specieIcons = {
        'Credit Card': faCreditCard,
        'Cash': faMoneyBill,
        'Online Payment': faCashRegister,
        // Adicione mais mapeamentos conforme necessário...
    };

    useEffect(() => {
        const loadData = async () => {
            try {
                setLoading(true);
                const data = await fetchOnlineData(); // Sem datas necessárias
                setFinalizadoras(data.finalizadoras);
                setPdvsOnline(data.pdvs_online);
                setLoading(false);
            } catch (err) {
                console.error('Erro ao buscar dados online:', err);
                setError('Falha ao carregar dados.');
                setLoading(false);
            }
        };

        loadData();
    }, []);

    useEffect(() => {
        if (!loading && !error) {
            let totalValue = 0;
            let totalFinalizadoras = {};
            let labels = [];
            let pieSeries = [];

            if (selectedFilial === 'All') {
                // Soma o total para cada finalizadora em todas as filiais
                totalFinalizadoras = Object.entries(finalizadoras).reduce((acc, [especie, total]) => {
                    acc[especie] = (acc[especie] || 0) + total;
                    totalValue += total;
                    return acc;
                }, {});
            } else if (selectedPDV === 'All') {
                // Soma o total para cada finalizadora em todos os PDVs da filial selecionada
                const filteredPdvs = pdvsOnline[selectedFilial] || {};

                Object.values(filteredPdvs).forEach(pdv => {
                    Object.entries(pdv).forEach(([especie, total]) => {
                        totalFinalizadoras[especie] = (totalFinalizadoras[especie] || 0) + total;
                        totalValue += total;
                    });
                });

                // Calcula os totais por PDV e prepara os dados para o gráfico de PDVs
                const pdvTotals = {};
                Object.entries(filteredPdvs).forEach(([pdv, finalizadoras]) => {
                    pdvTotals[pdv] = Object.values(finalizadoras).reduce((acc, total) => acc + total, 0);
                });

                setPdvChartData({
                    labels: Object.keys(pdvTotals),
                    series: [{
                        data: Object.values(pdvTotals).map(total => (total / totalValue) * 100), // Corrigido: usando array de objetos
                    }],
                });

            } else {
                // Mostrar dados apenas para o PDV selecionado
                const selectedPDVData = pdvsOnline[selectedFilial]?.[selectedPDV] || {};
                totalFinalizadoras = selectedPDVData;
                totalValue = Object.values(selectedPDVData).reduce((acc, total) => acc + total, 0);
            }

            Object.entries(totalFinalizadoras).forEach(([especie, total]) => {
                labels.push(especie);
                pieSeries.push((total / totalValue) * 100); // Calcula o percentual
            });

            setPieChartData({
                series: pieSeries,
                labels
            });

            setTotalPorFinalizadora(totalFinalizadoras);
            setTotalFinalizadorasValue(totalValue);
        }
    }, [selectedFilial, selectedPDV, finalizadoras, pdvsOnline, loading, error]);

    const handleFilialChange = (e) => {
        setSelectedFilial(e.target.value);
        setSelectedPDV('All'); // Resetar seleção de PDV ao mudar filial
    };

    const handlePDVChange = (e) => {
        setSelectedPDV(e.target.value);
    };

    const handleTogglePDVDetails = () => {
        setShowPDVDetails(prevState => !prevState);
    };

    const pieChartOptions = {
        chart: {
            type: 'pie',
            height: 400,
        },
        labels: pieChartData.labels,
        legend: {
            position: 'bottom',
        },
        tooltip: {
            y: {
                formatter: (val) => {
                    const total = (val / 100) * totalFinalizadorasValue; // Calcula o valor total a partir do percentual
                    return `R$ ${total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} (${val.toFixed(2)}%)`;
                }
            }
        },
        colors: ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#8e44ad'] // Adicione mais cores conforme necessário
    };

    const pdvChartOptions = {
        chart: {
            type: 'bar',
            height: 400,
            toolbar: {
                show: false,
            },
        },
        plotOptions: {
            bar: {
                horizontal: false,  // Colunas na vertical
                columnWidth: '50%',  // Ajusta a largura das colunas
                distributed: true,   // Distribui as barras com diferentes cores, se desejado
            },
        },
        dataLabels: {
            enabled: true,
            formatter: (val) => `${val.toFixed(2)}%`,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                colors: ['#333'],
            },
        },
        xaxis: {
            categories: pdvChartData.labels.map(label => `PDV ${label}`),  // Certifique-se de usar os rótulos corretos
            labels: {
                style: {
                    colors: ['#333'],
                    fontSize: '12px',
                    fontWeight: 'bold',
                },
            },
        },
        yaxis: {
            min: 0.1, // Define o valor mínimo para exibir no eixo Y, assim zeros são removidos
            labels: {
                style: {
                    colors: ['#333'],
                    fontSize: '14px',
                    fontWeight: 'bold',
                },
                formatter: (val) => {
                    return val >= 0.1 ? val.toFixed(1) : ''; // Exibe apenas valores significativos
                },
            },
            title: {
                text: 'Percentage (%)',
                style: {
                    color: '#333',
                    fontSize: '16px',
                    fontWeight: 'bold',
                },
            },
        },
        colors: ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#8e44ad'], // Cores vibrantes para cada PDV
        tooltip: {
            enabled: true,
            theme: 'dark', // Mudar para um tema escuro para contraste
            y: {
                formatter: (val) => {
                    const total = (val / 100) * totalFinalizadorasValue; // Calcula o valor total a partir do percentual
                    return `R$ ${total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} (${val.toFixed(2)}%)`;
                }
            },
        },
        grid: {
            borderColor: '#ddd', // Uma cor mais suave para as linhas da grade
            strokeDashArray: 4,
        },
    };
    
    

    if (loading) {
        return <p>Carregando dados...</p>;
    }

    if (error) {
        return <p>{error}</p>;
    }

    return (
        <Container>
            <Title>Finalizadoras Online</Title>

            <FilterContainer>
                <Label htmlFor="filial">Filtrar por Filial:</Label>
                <Select id="filial" value={selectedFilial} onChange={handleFilialChange}>
                    <Option value="All">Todas as Filiais</Option>
                    {Object.keys(pdvsOnline).map(filial => (
                        <Option key={filial} value={filial}>Filial {filial}</Option>
                    ))}
                </Select>

                {selectedFilial !== 'All' && (
                    <>
                        <Label htmlFor="pdv">Filtrar por PDV:</Label>
                        <Select id="pdv" value={selectedPDV} onChange={handlePDVChange}>
                            <Option value="All">Todos os PDVs</Option>
                            {Object.keys(pdvsOnline[selectedFilial] || {}).map(pdv => (
                                <Option key={pdv} value={pdv}>PDV {pdv}</Option>
                            ))}
                        </Select>
                    </>
                )}
            </FilterContainer>

            <PieChartWrapper>
                <Chart
                    options={pieChartOptions}
                    series={pieChartData.series}
                    type="pie"
                    height={400}
                />
            </PieChartWrapper>


            <TotalValueContainer>
                <TotalValueLabel>Total de Todas Finalizadoras:</TotalValueLabel>
                <TotalValue>R$ {totalFinalizadorasValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</TotalValue>
            </TotalValueContainer>

            <Section>
                <SectionTitle>Total por Finalizadora</SectionTitle>
                <List>
                    {Object.entries(totalPorFinalizadora).map(([especie, total]) => (
                        <ListItem key={especie}>
                            <Icon icon={specieIcons[especie] || faCreditCard} />
                            <ListItemLabel>{especie}:</ListItemLabel>
                            <ListItemValue>R$ {total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</ListItemValue>
                        </ListItem>
                    ))}
                </List>
            </Section>
            {selectedFilial !== 'All' && (
                <Section>
                    <SectionTitle>Análise por PDV</SectionTitle>
                    <ChartContainer>
            <Chart
                options={pdvChartOptions}
                series={pdvChartData.series}
                type="bar"
                height={600} // Reflete a altura do gráfico configurada acima
            />
        </ChartContainer>
                </Section>
            )}

            {selectedFilial !== 'All' && (
                <Button onClick={handleTogglePDVDetails}>
                    {showPDVDetails ? 'Esconder Detalhes por PDV' : 'Exibir Detalhes por PDV'}
                </Button>
            )}

            {showPDVDetails && selectedFilial !== 'All' && selectedPDV === 'All' && (
                <Section>
                    <SectionTitle>Detalhes por PDV</SectionTitle>
                    <PDVContainer>
                        {Object.entries(pdvsOnline[selectedFilial] || {}).map(([pdv, finalizadoras]) => (
                            <PDVDetails key={pdv}>
                                <PDVTitle>PDV {pdv}</PDVTitle>
                                <List>
                                    {Object.entries(finalizadoras).map(([especie, total]) => (
                                        <ListItem key={especie}>
                                            <Icon icon={specieIcons[especie] || faCreditCard} />
                                            <ListItemLabel>{especie}:</ListItemLabel>
                                            <ListItemValue>R$ {total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</ListItemValue>
                                        </ListItem>
                                    ))}
                                </List>
                            </PDVDetails>
                        ))}
                    </PDVContainer>
                </Section>
            )}
        </Container>
    );
};

export default FinalizadorasOnline;
