import PropTypes from "prop-types";
import { useState, useEffect } from "react";
import Chart from "react-apexcharts";
import {
  ShowMoreButton,
  PeriodSelector,
  ChartWrapper,
  MonthSelector,
  PeriodSelectorOption,
  ReportItem,
  ReportItemFaturamento
} from "../VendasMes/styles";
import { FaDollarSign } from "react-icons/fa";

const FaturamentoChart = ({ faturamentoData }) => {
  const [selectedFilial, setSelectedFilial] = useState("All");
  const [selectedMonth, setSelectedMonth] = useState("");
  const [chartData, setChartData] = useState({ series: [], categories: [] });
  const [showAll, setShowAll] = useState(false);
  const [totalFaturamento, setTotalFaturamento] = useState(0);

  useEffect(() => {
    if (faturamentoData) {
      updateChartData();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [faturamentoData, selectedFilial, selectedMonth, showAll]);

  const updateChartData = () => {
    let dataToShow = [];

    if (selectedFilial === "All") {
        // Aggregate data across all filials by month
        const aggregatedData = {};
        faturamentoData.forEach((filial) => {
            filial.faturamento.forEach((item) => {
                if (!aggregatedData[item.month_year]) {
                    aggregatedData[item.month_year] = 0;
                }
                aggregatedData[item.month_year] += parseFloat(item.total_faturamento);
            });
        });

        // Convert aggregated data to the format needed for the chart
        dataToShow = Object.keys(aggregatedData).map((month_year) => ({
            month_year,
            total_faturamento: aggregatedData[month_year].toString(),
        }));
    } else {
        const filialData = faturamentoData.find((filial) => filial.codfil === parseInt(selectedFilial));
        if (filialData) {
            dataToShow = filialData.faturamento;
        }
    }

    if (selectedMonth) {
        dataToShow = dataToShow.filter((item) => item.month_year === selectedMonth);
    }

    dataToShow = showAll ? dataToShow : dataToShow.slice(-3);

    const faturamentoValues = dataToShow.map((item) => parseFloat(item.total_faturamento));
    const totalFaturamentoValue = faturamentoValues.reduce((acc, val) => acc + val, 0);
    const categories = dataToShow.map((item) => item.month_year);

    setChartData({
        series: [
            {
                name: selectedFilial === "All" ? "Todas as Filiais" : `Filial ${selectedFilial}`,
                data: faturamentoValues,
            },
        ],
        categories: categories,
    });

    setTotalFaturamento(totalFaturamentoValue);
};

  const handleChangeFilial = (event) => {
    setSelectedFilial(event.target.value);
    setSelectedMonth(""); // Reset month when changing filial
  };

  const handleChangeMonth = (event) => {
    setSelectedMonth(event.target.value);
  };

  const handleShowMore = () => {
    setShowAll(!showAll);
  };

  const chartOptions = {
    chart: {
      type: "bar",
      height: "400px",
      toolbar: {
        show: false,
      },
      background: "#f4f4f4",
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: "60%",
        endingShape: "rounded",
        borderRadius: 5,
      },
    },
    dataLabels: {
      enabled: false,
    },
    xaxis: {
      categories: chartData.categories,
      labels: {
        show: true,
        rotate: -45,
        style: {
          fontSize: "12px",
          colors: "#333",
        },
      },
    },
    yaxis: {
      title: {
        text: "Faturamento (BRL)",
        style: {
          fontSize: "14px",
          color: "#333",
        },
      },
      labels: {
        formatter: function (val) {
          return `R$ ${val.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`;
        },
      },
    },
    fill: {
      opacity: 0.8,
      type: "gradient",
      gradient: {
        shade: "light",
        type: "vertical",
        shadeIntensity: 0.3,
        gradientToColors: ["#1E90FF", "#FF9F43"],
        inverseColors: false,
        stops: [0, 100],
      },
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return `R$ ${val.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`;
        },
      },
      theme: "light",
    },
    colors: ["#1E90FF", "#FF6347", "#32CD32"],
    title: {
      text: `Gráfico de Faturamento - ${selectedFilial === "All" ? "Todas as Filiais" : `Filial ${selectedFilial}`}${selectedMonth ? ` (${selectedMonth})` : ''}`,
      align: "center",
      style: {
        fontSize: "16px",
        fontWeight: "bold",
        color: "#333",
      },
    },
    responsive: [
      {
        breakpoint: 2000,
        options: {
          plotOptions: {
            bar: {
              columnWidth: "70%",
            },
          },
          xaxis: {
            labels: {
              style: {
                fontSize: "14px",
              },
            },
          },
        },
      },
      {
        breakpoint: 600,
        options: {
          chart: {
            height: 350,
            width: "100%",
          },
          plotOptions: {
            bar: {
              columnWidth: "90%",
            },
          },
          xaxis: {
            labels: {
              style: {
                fontSize: "10px",
              },
            },
            tickAmount: 5,
          },
          title: {
            style: {
              fontSize: "14px",
            },
          },
        },
      },
    ],
  };

  return (
    <ChartWrapper>
      <ReportItemFaturamento>
        <ReportItem color="#102C57">
          <FaDollarSign />
          <p>
            Total Faturamento: R${" "}
            {totalFaturamento.toLocaleString("pt-BR", {
              minimumFractionDigits: 2,
            })}
          </p>
        </ReportItem>
      </ReportItemFaturamento>

      <PeriodSelector value={selectedFilial} onChange={handleChangeFilial}>
        <PeriodSelectorOption value="All">Todas as Filiais</PeriodSelectorOption>
        {faturamentoData && faturamentoData.map(filial => (
          <PeriodSelectorOption key={filial.codfil} value={filial.codfil}>
            Filial {filial.codfil}
          </PeriodSelectorOption>
        ))}
      </PeriodSelector>

      {selectedFilial !== "All" && (
        <MonthSelector value={selectedMonth} onChange={handleChangeMonth}>
          <PeriodSelectorOption value="">Todos os Meses</PeriodSelectorOption>
          {faturamentoData
            .find(filial => filial.codfil === parseInt(selectedFilial))
            ?.faturamento.map(item => (
              <PeriodSelectorOption key={item.month_year} value={item.month_year}>
                {item.month_year}
              </PeriodSelectorOption>
            ))}
        </MonthSelector>
      )}

      <Chart
        options={chartOptions}
        series={chartData.series}
        type="bar"
        height={400}
      />

      <ShowMoreButton onClick={handleShowMore}>
        {showAll ? "Mostrar menos" : "Mostrar mais"}
      </ShowMoreButton>
    </ChartWrapper>
  );
};

// PropTypes validation
FaturamentoChart.propTypes = {
  faturamentoData: PropTypes.arrayOf(
    PropTypes.shape({
      codfil: PropTypes.number.isRequired,
      faturamento: PropTypes.arrayOf(
        PropTypes.shape({
          month_year: PropTypes.string.isRequired,
          total_faturamento: PropTypes.string.isRequired,
        })
      ).isRequired,
    })
  ).isRequired,
};

export default FaturamentoChart;
