import styled from "styled-components";

export const ContainerFilter = styled.div`
    margin-bottom: 16px;
`;

export const Label = styled.label`
    font-size: 14px;
    margin-right: 8px;
    color: #333;
`;

export const Select = styled.select`
    padding: 8px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-right: 16px;
    background-color: #f8f8f8;
    color: #333;

    &:focus {
        outline: none;
        border-color: #0090FF;
    }
`;

export const Option = styled.option`
    font-size: 14px;
`;

export const Title = styled.h1`
    display: flex;
    justify-content: center;
`;

export const CardWrapper = styled.div`
    background: #333;
    color: #fff;
    border-radius: 8px;
    padding: 15px;
    width: 200px;
    display: flex;
    align-items: center;
    margin-bottom: 15px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`;

export const IconWrapper = styled.div`
    font-size: 24px;
    margin-right: 15px;
`;

export const CardContent = styled.div`
    display: flex;
    flex-direction: column;
`;

export const CardTitle = styled.h4`
    font-size: 16px;
    margin-bottom: 5px;
`;

export const CardValue = styled.p`
    font-size: 18px;
    font-weight: bold;
`;

export const ChartWrapper = styled.div`
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-top: 20px;
`;

export const CardsContainer = styled.div`
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    margin-top: 20px;
`;
