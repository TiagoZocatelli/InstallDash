import { useState, useEffect } from 'react';
import Chart from 'react-apexcharts';
import { fetchComparativoAno } from '../../../api/API-ANO';
import { ChartWrapper } from '../VendasMes/styles';
import { Label, Select, Option, Title, ContainerFilter } from './styles'; // Importando os estilos

const ComparativoAno = () => {
    const [comparativoData, setComparativoData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedFilial, setSelectedFilial] = useState('21'); // Definindo "21" como filial padrão
    const [selectedMonth, setSelectedMonth] = useState('01'); // Definindo "01" como mês padrão
    const [chartData, setChartData] = useState(null);

    const fetchComparativoData = async () => {
        try {
            const data = await fetchComparativoAno();
            setComparativoData(data.dados); // Ajustando para a nova estrutura
            setLoading(false);
        } catch (error) {
            console.error('Erro ao buscar dados comparativos:', error);
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchComparativoData();
    }, []);

    useEffect(() => {
        const generateChartData = () => {
            let filteredData;

            // Encontrar os dados da filial selecionada
            const filialData = comparativoData.find(filial => filial.filial === selectedFilial);
            filteredData = filialData ? filialData.dados_filial : [];

            // Filtrar os dados pelo mês selecionado
            filteredData = filteredData.filter(item => item.mes_ano.startsWith(selectedMonth));

            const categories = filteredData.map(item => item.mes_ano);
            const currentYearVendas = filteredData.map(item => parseValue(item.ano_atual.totvrvenda));
            const previousYearVendas = filteredData.map(item => parseValue(item.ano_anterior.totvrvenda));

            setChartData({
                categories,
                series: [
                    {
                        name: 'Vendas (Ano Atual)',
                        data: currentYearVendas,
                    },
                    {
                        name: 'Vendas (Ano Anterior)',
                        data: previousYearVendas,
                    }
                ],
                filteredData,
            });
        };

        if (comparativoData.length > 0 && selectedFilial) {
            generateChartData();
        }
    }, [selectedFilial, selectedMonth, comparativoData]);

    const handleFilialChange = (event) => {
        setSelectedFilial(event.target.value);
    };

    const handleMonthChange = (event) => {
        setSelectedMonth(event.target.value);
    };

    const parseValue = (value) => {
        const parsed = parseFloat(value);
        return isNaN(parsed) ? 0 : parsed;
    };

    const formatChangeValue = (value) => {
        const parsedValue = parseFloat(value);
        return isNaN(parsedValue) ? "0.00%" : `${parsedValue.toFixed(2)}%`;
    };

    const calculateTicketMedio = (vendas, clientes) => {
        if (!clientes || clientes === 0) return 0;
        return vendas / clientes;
    };
    
    const calculateVendasChange = (current, previous) => {
        if (!previous || previous === 0) return current ? "100%" : "0%";
        const change = ((current - previous) / previous) * 100;
        return `${change.toFixed(2)}%`;
    };

    const chartOptions = {
        chart: {
            height: '400px',
            toolbar: {
                show: true,
            },
        },
        plotOptions: {
            bar: {
                borderRadius: 5,
                horizontal: false,
                columnWidth: '50%',
            },
        },
        colors: ['#00E396', '#0090FF'],
        stroke: {
            show: true,
            width: 2,
            colors: ['transparent'],
        },
        dataLabels: {
            enabled: false, // Desativar os rótulos de valores nas barras
        },
        xaxis: {
            categories: chartData ? chartData.categories : [],
        },
        yaxis: {
            title: {
                text: 'Valores (BRL)',
            },
            labels: {
                show: true, // Mostrar os valores no eixo Y (à esquerda)
            },
        },
        fill: {
            opacity: 1,
            type: 'gradient',
            gradient: {
                shade: 'dark',
                type: 'vertical',
                shadeIntensity: 0.5,
                gradientToColors: undefined,
                inverseColors: true,
                opacityFrom: 0.85,
                opacityTo: 0.85,
                stops: [0, 100]
            }
        },
        tooltip: {
            shared: true,
            intersect: false,
            custom: ({ dataPointIndex }) => {
                if (!chartData) return '';
                const item = chartData.filteredData[dataPointIndex];
                const currentYear = item.ano_atual || {};
                const previousYear = item.ano_anterior || {};
                const vendasChange = calculateVendasChange(currentYear.totvrvenda, previousYear.totvrvenda);
                const changes = item.mudancas || {};
        
                // Calculate ticket médio
                const ticketMedioAtual = calculateTicketMedio(parseValue(currentYear.totvrvenda), parseValue(currentYear.nclientes));
                const ticketMedioAnterior = calculateTicketMedio(parseValue(previousYear.totvrvenda), parseValue(previousYear.nclientes));
                const ticketMedioChange = calculateVendasChange(ticketMedioAtual, ticketMedioAnterior);

                const getIcon = (change) => {
                    return parseFloat(change) >= 0 ? '📈' : '📉';
                };
        
                const getColor = (change) => {
                    return parseFloat(change) >= 0 ? '#00E396' : '#FF4560';
                };
        
                const formatTooltipRow = (label, value, change) => {
                    return `
                        <div style="margin-top: 8px; display: flex; justify-content: space-between;">
                            <span style="color: ${getColor(change)}; font-weight: bold;">${getIcon(change)} ${label}:</span>
                            <span style="color: #fff;">${value} (${formatChangeValue(change)})</span>
                        </div>
                    `;
                };
        
                return `
                    <div style="background-color: #222; color: #fff; padding: 15px; border-radius: 8px; width: 280px; font-family: Arial, sans-serif; font-size: 14px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                        <strong style="font-size: 18px; display: block; margin-bottom: 10px;">Mês: ${item.mes_ano}</strong>
                        <div style="margin-bottom: 12px;">
                            <strong style="color: #00E396; font-size: 16px;">Ano Atual:</strong><br/>
                            ${formatTooltipRow('Vendas', `R$ ${parseValue(currentYear.totvrvenda).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, vendasChange)}
                            ${formatTooltipRow('Clientes', parseValue(currentYear.nclientes).toLocaleString('pt-BR'), changes.nclientes_change)}
                            ${formatTooltipRow('Produtos', parseValue(currentYear.totprodvda).toLocaleString('pt-BR'), changes.totprodvda_change)}
                            ${formatTooltipRow('Custo', `R$ ${parseValue(currentYear.totvrcusto).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, changes.totvrcusto_change)}
                            ${formatTooltipRow('Ticket Médio', `R$ ${ticketMedioAtual.toFixed(2)}`, ticketMedioChange)}
                        </div>
                        <div style="margin-bottom: 12px;">
                            <strong style="color: #0090FF; font-size: 16px;">Ano Anterior:</strong><br/>
                            <div style="margin-top: 8px; display: flex; justify-content: space-between;">
                                <span style="color: #ccc;">Vendas:</span>
                                <span style="color: #fff;">R$ ${parseValue(previousYear.totvrvenda).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                            </div>
                            <div style="margin-top: 8px; display: flex; justify-content: space-between;">
                                <span style="color: #ccc;">Clientes:</span>
                                <span style="color: #fff;">${parseValue(previousYear.nclientes).toLocaleString('pt-BR')}</span>
                            </div>
                            <div style="margin-top: 8px; display: flex; justify-content: space-between;">
                                <span style="color: #ccc;">Produtos:</span>
                                <span style="color: #fff;">${parseValue(previousYear.totprodvda).toLocaleString('pt-BR')}</span>
                            </div>
                            <div style="margin-top: 8px; display: flex; justify-content: space-between;">
                                <span style="color: #ccc;">Custo:</span>
                                <span style="color: #fff;">R$ ${parseValue(previousYear.totvrcusto).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                            </div>
                            <div style="margin-top: 8px; display: flex; justify-content: space-between;">
                                <span style="color: #ccc;">Ticket Médio:</span>
                                <span style="color: #fff;">R$ ${ticketMedioAnterior.toFixed(2)}</span>
                            </div>
                        </div>
                    </div>
                `;
            }
        }
        ,
        legend: {
            position: 'bottom',
            horizontalAlign: 'center',
        }
    };

    return (
        <ChartWrapper>
            <Title>Comparativo Ano a Ano</Title>
            <ContainerFilter>
                <Label htmlFor="filial">Filtrar por Filial:</Label>
                <Select id="filial" value={selectedFilial} onChange={handleFilialChange}>
                    {comparativoData.length > 0 &&
                        comparativoData.map((filial) => (
                            <Option key={filial.filial} value={filial.filial}>
                                Filial {filial.filial}
                            </Option>
                        ))}
                </Select>
            </ContainerFilter>
            <ContainerFilter>
                <Label htmlFor="mes">Filtrar por Mês:</Label>
                <Select id="mes" value={selectedMonth} onChange={handleMonthChange}>
                    <Option value="01">Janeiro</Option>
                    <Option value="02">Fevereiro</Option>
                    <Option value="03">Março</Option>
                    <Option value="04">Abril</Option>
                    <Option value="05">Maio</Option>
                    <Option value="06">Junho</Option>
                    <Option value="07">Julho</Option>
                    <Option value="08">Agosto</Option>
                    <Option value="09">Setembro</Option>
                    <Option value="10">Outubro</Option>
                    <Option value="11">Novembro</Option>
                    <Option value="12">Dezembro</Option>
                </Select>
            </ContainerFilter>
            {loading ? (
                <p>Carregando dados...</p>
            ) : (
                chartData && (
                    <Chart
                        options={chartOptions}
                        series={chartData.series}
                        type="bar"
                        height={400}
                        key={selectedFilial + selectedMonth} // Forçar re-renderização ao mudar de filial ou mês
                    />
                )
            )}
        </ChartWrapper>
    );
};

export default ComparativoAno;