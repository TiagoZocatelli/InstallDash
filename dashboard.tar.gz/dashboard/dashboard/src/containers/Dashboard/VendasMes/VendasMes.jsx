/* eslint-disable react/prop-types */
import { useState, useEffect } from "react";
import Chart from "react-apexcharts";
import {
  ShowMoreButton,
  PeriodSelector,
  ChartWrapper,
  Report,
  ReportItem,
  MonthSelector,
  PeriodSelectorOption
} from "./styles";
import {
  FaDollarSign,
  FaShoppingCart,
  FaMoneyBillWave,
  FaUsers,
  FaBoxOpen,
  FaPercentage,
} from "react-icons/fa";


const SalesBarChart = ({ vendasMensais }) => {
  const [selectedPeriod, setSelectedPeriod] = useState("");
  const [selectedMonth, setSelectedMonth] = useState("");
  const [chartData, setChartData] = useState({ series: [], categories: [] });
  const [clientData, setClientData] = useState({ series: [], categories: [] });
  const [showAll, setShowAll] = useState(false);
  const [reportData, setReportData] = useState({
    
    vendas: 0,
    custos: 0,
    lucros: 0,
    clientes: 0,
    produtos: 0,
    lucroPercent: 0,
    ticketMedio: 0,
  });

  const handleChangePeriod = (event) => {
    setSelectedPeriod(event.target.value);
    setSelectedMonth("");
  };

  const handleChangeMonth = (event) => {
    setSelectedMonth(event.target.value);
  };

  const handleShowMore = () => {
    setShowAll(!showAll);
  };

  useEffect(() => {
    if (vendasMensais && !selectedPeriod) {
      setSelectedPeriod("Todas");
    }
  }, [vendasMensais, selectedPeriod]);

  useEffect(() => {
    if (vendasMensais) {
      let dataToShow = [];

      if (selectedPeriod === "Todas") {
        const aggregatedData = {};

        Object.values(vendasMensais).forEach((branchData) => {
          branchData.forEach((item) => {
            if (!aggregatedData[item.mes]) {
              aggregatedData[item.mes] = {
                vendas: 0,
                custos: 0,
                lucros: 0,
                clientes: 0,
                produtos: 0,
              };
            }
            aggregatedData[item.mes].vendas += parseFloat(item.totvrvenda);
            aggregatedData[item.mes].custos += parseFloat(item.totvrcusto);
            aggregatedData[item.mes].lucros +=
              parseFloat(item.totvrvenda) - parseFloat(item.totvrcusto);
            aggregatedData[item.mes].clientes += parseFloat(item.nclientes);
            aggregatedData[item.mes].produtos += parseFloat(item.totprodvda);
          });
        });

        dataToShow = Object.keys(aggregatedData).map((mes) => ({
          mes,
          ...aggregatedData[mes],
        }));

        dataToShow = showAll ? dataToShow : dataToShow.slice(-3);

        const vendas = dataToShow.map((item) => item.vendas);
        const custos = dataToShow.map((item) => item.custos);
        const lucros = dataToShow.map((item) => item.lucros);
        const nclientes = dataToShow.map((item) => item.clientes);
        const produtos = dataToShow.map((item) => item.produtos);

        const totalVendas = vendas.reduce((acc, val) => acc + val, 0);
        const totalCustos = custos.reduce((acc, val) => acc + val, 0);
        const totalLucros = lucros.reduce((acc, val) => acc + val, 0);
        const totalClientes = nclientes.reduce((acc, val) => acc + val, 0);
        const totalProdutos = produtos.reduce((acc, val) => acc + val, 0);
        const lucroPercent = totalVendas
          ? ((totalLucros / totalVendas) * 100).toFixed(2)
          : 0;

        const totalTicketMedio =
          totalClientes > 0 ? totalVendas / totalClientes : 0;

        setReportData({
          vendas: totalVendas,
          custos: totalCustos,
          lucros: totalLucros,
          clientes: totalClientes,
          produtos: totalProdutos,
          lucroPercent: lucroPercent,
          ticketMedio: totalTicketMedio,
        });

        setChartData({
          series: [
            {
              name: "Total de Vendas",
              data: vendas,
            },
            {
              name: "Total de Custo",
              data: custos,
            },
            {
              name: "Lucro",
              data: lucros,
            },
          ],
          categories: dataToShow.map((item) => item.mes),
        });

        setClientData({
          series: [
            {
              name: "Número de Clientes",
              data: nclientes,
            },
          ],
          categories: dataToShow.map((item) => item.mes),
        });
      } else {
        dataToShow = vendasMensais[selectedPeriod] || [];

        if (selectedMonth) {
          dataToShow = dataToShow.filter((item) => item.mes === selectedMonth);
        }

        dataToShow = showAll ? dataToShow : dataToShow.slice(-3);

        const vendas = dataToShow.map((item) => parseFloat(item.totvrvenda));
        const custos = dataToShow.map((item) => parseFloat(item.totvrcusto));
        const lucros = vendas.map((venda, index) => venda - custos[index]);
        const nclientes = dataToShow.map((item) => parseFloat(item.nclientes));
        const produtos = dataToShow.map((item) => parseFloat(item.totprodvda));

        const totalVendas = vendas.reduce((acc, val) => acc + val, 0);
        const totalCustos = custos.reduce((acc, val) => acc + val, 0);
        const totalLucros = lucros.reduce((acc, val) => acc + val, 0);
        const totalClientes = nclientes.reduce((acc, val) => acc + val, 0);
        const totalProdutos = produtos.reduce((acc, val) => acc + val, 0);
        const lucroPercent = totalVendas
          ? ((totalLucros / totalVendas) * 100).toFixed(2)
          : 0;

        const totalTicketMedio =
          totalClientes > 0 ? totalVendas / totalClientes : 0;

        setReportData({
          vendas: totalVendas,
          custos: totalCustos,
          lucros: totalLucros,
          clientes: totalClientes,
          produtos: totalProdutos,
          lucroPercent: lucroPercent,
          ticketMedio: totalTicketMedio,
        });

        setChartData({
          series: [
            {
              name: "Total de Vendas",
              data: vendas,
            },
            {
              name: "Total de Custo",
              data: custos,
            },
            {
              name: "Lucro",
              data: lucros,
            },
          ],
          categories: dataToShow.map((item) => item.mes),
        });

        setClientData({
          series: [
            {
              name: "Número de Clientes",
              data: nclientes,
            },
          ],
          categories: dataToShow.map((item) => item.mes),
        });
      }
    }
  }, [vendasMensais, selectedPeriod, selectedMonth, showAll]);

  const chartOptions = {
    chart: {
      type: "bar",
      height: "400px",
      toolbar: {
        show: false,
      },
      background: "#f4f4f4",
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: "60%",
        endingShape: "rounded",
        borderRadius: 5,
      },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      show: true,
      width: 2,
      colors: ["#fff"],
    },
    xaxis: {
      categories: chartData.categories,
      labels: {
        show: true,
        rotate: -45,
        style: {
          fontSize: "12px",
          colors: "#333",
        },
      },
    },
    yaxis: {
      title: {
        text: "Valores (BRL)",
        style: {
          fontSize: "14px",
          color: "#333",
        },
      },
      labels: {
        formatter: function (val) {
          return val.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
        },
      },
    },
    fill: {
      opacity: 0.8,
      type: "gradient",
      gradient: {
        shade: "light",
        type: "vertical",
        shadeIntensity: 0.3,
        gradientToColors: ["#77B6EA", "#FF9F43"],
        inverseColors: false,
        stops: [0, 100],
      },
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return `R$ ${val.toLocaleString("pt-BR", {
            minimumFractionDigits: 2,
          })}`;
        },
      },
      theme: "light",
    },
    colors: ["#1E90FF", "#FF6347", "#32CD32"],
    title: {
      text: `Gráfico de Vendas - ${selectedPeriod}${
        selectedMonth ? ` (${selectedMonth})` : ""
      }`,
      align: "center",
      style: {
        fontSize: "16px",
        fontWeight: "bold",
        color: "#333",
      },
    },
    responsive: [
      {
        breakpoint: 2000,
        options: {
          plotOptions: {
            bar: {
              columnWidth: "70%",
            },
          },
          xaxis: {
            labels: {
              style: {
                fontSize: "14px",
              },
            },
          },
        },
      },
      {
        breakpoint: 600,
        options: {
          chart: {
            height: 350,
            width: "100%",
          },
          plotOptions: {
            bar: {
              columnWidth: "90%",
            },
          },
          xaxis: {
            labels: {
              style: {
                fontSize: "10px",
              },
            },
            tickAmount: 5,
          },
          title: {
            style: {
              fontSize: "14px",
            },
          },
        },
      },
    ],
  };

  const clientChartOptions = {
    chart: {
      type: "area",
      height: "400px",
      toolbar: {
        show: false,
      },
      background: "#f4f4f4",
    },
    stroke: {
      curve: "smooth",
      width: 2,
      colors: ["#FF5733"],
    },
    fill: {
      type: "gradient",
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.7,
        opacityTo: 0.3,
        stops: [0, 100],
        colorStops: [
          {
            offset: 0,
            color: "#FF5733",
            opacity: 0.7,
          },
          {
            offset: 100,
            color: "#FFC300",
            opacity: 0.3,
          },
        ],
      },
    },
    xaxis: {
      categories: clientData.categories,
      labels: {
        show: true,
        rotate: -45,
        style: {
          fontSize: "12px",
          colors: ["#333"],
        },
      },
    },
    yaxis: {
      title: {
        text: "Número de Clientes",
        style: {
          fontSize: "14px",
          color: "#333",
        },
      },
    },
    markers: {
      size: 4,
      colors: ["#FF5733"],
      strokeColors: "#FFC300",
      strokeWidth: 2,
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return `${val} Clientes`;
        },
      },
      theme: "light",
    },
    title: {
      text: `Número de Clientes - ${selectedPeriod}${
        selectedMonth ? ` (${selectedMonth})` : ""
      }`,
      align: "center",
      style: {
        fontSize: "16px",
        fontWeight: "bold",
        color: "#333",
      },
    },
    responsive: [
      {
        breakpoint: 2000,
        options: {
          xaxis: {
            labels: {
              style: {
                fontSize: "14px",
              },
            },
          },
        },
      },
      {
        breakpoint: 600,
        options: {
          chart: {
            height: 350,
            width: "100%",
          },
          xaxis: {
            labels: {
              style: {
                fontSize: "10px",
              },
            },
            tickAmount: 5,
          },
          title: {
            style: {
              fontSize: "14px",
            },
          },
        },
      },
    ],
  };

  return (
    <ChartWrapper>
      <Report>
        <ReportItem color="#1E90FF">
          <FaShoppingCart />
          <p>
            Total Vendas: R${" "}
            {reportData.vendas.toLocaleString("pt-BR", {
              minimumFractionDigits: 2,
            })}
          </p>
        </ReportItem>
        <ReportItem color="#FF6347">
          <FaMoneyBillWave />
          <p>
            Total Custos: R${" "}
            {reportData.custos.toLocaleString("pt-BR", {
              minimumFractionDigits: 2,
            })}
          </p>
        </ReportItem>
        <ReportItem color="#32CD32">
          <FaDollarSign />
          <p>
            Total Lucros: R${" "}
            {reportData.lucros.toLocaleString("pt-BR", {
              minimumFractionDigits: 2,
            })}
          </p>
        </ReportItem>
        <ReportItem color="#FF5733">
          <FaUsers />
          <p>
            Total Clientes:{" "}
            {reportData.clientes.toLocaleString("pt-BR", {
              minimumFractionDigits: 0,
            })}
          </p>
          <p>
            Ticket Médio: R${" "}
            {reportData.ticketMedio.toLocaleString("pt-BR", {
              minimumFractionDigits: 2,
            })}
          </p>
        </ReportItem>

        <ReportItem color="#FFC300">
          <FaBoxOpen />
          <p>
            Total Produtos Vendidos:{" "}
            {reportData.produtos.toLocaleString("pt-BR", {
              minimumFractionDigits: 0,
            })}
          </p>
        </ReportItem>
        <ReportItem color="#20B2AA">
          <FaPercentage />
          <p>Lucro (%): {reportData.lucroPercent}%</p>
        </ReportItem>
      </Report>

      <PeriodSelector value={selectedPeriod} onChange={handleChangePeriod}>
        <PeriodSelectorOption value="Todas">Todas</PeriodSelectorOption>
        {Object.keys(vendasMensais || {}).map((period) => (
          <PeriodSelectorOption key={period} value={period}>
            {period}
          </PeriodSelectorOption>
        ))}
      </PeriodSelector>

      {selectedPeriod !== "Todas" && (
        <MonthSelector value={selectedMonth} onChange={handleChangeMonth}>
          <PeriodSelectorOption value="">Todos os Meses</PeriodSelectorOption>
          {vendasMensais[selectedPeriod] &&
            vendasMensais[selectedPeriod].map((item) => (
              <PeriodSelectorOption key={item.mes} value={item.mes}>
                {item.mes}
              </PeriodSelectorOption>
            ))}
        </MonthSelector>
      )}

      <Chart
        options={chartOptions}
        series={chartData.series}
        type="bar"
        height={400}
      />

      <ShowMoreButton onClick={handleShowMore}>
        {showAll ? "Mostrar menos" : "Mostrar mais"}
      </ShowMoreButton>

      <ChartWrapper>
        <Chart
          options={clientChartOptions}
          series={clientData.series}
          type="area"
          height={400}
        />
      </ChartWrapper>
    </ChartWrapper>
  );
};

export default SalesBarChart;

