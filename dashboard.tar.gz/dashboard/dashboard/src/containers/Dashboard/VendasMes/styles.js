import styled from "styled-components";

export const ChartWrapper = styled.div`
  width: 100%;
  max-width: 1500px;
  margin: 20px auto;
  padding: 20px;
  background: #ffffff; /* Fundo branco */
  border-radius: 16px;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08); /* Sombra suave */
  transition: box-shadow 0.3s ease, transform 0.3s ease;

  &:hover {
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
    transform: translateY(-5px); /* Elevação suave ao passar o mouse */
  }

  @media (max-width: 768px) {
    padding: 15px;
  }
`;

export const DaySelector = styled.select`
  margin: 10px 0;
  padding: 5px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid #ccc;
`;

export const Report = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr); /* Três colunas */
  gap: 20px;
  margin-bottom: 20px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 15px;
  }
`;

export const ReportItem = styled.div`
  background-color: ${(props) => props.color || "#f4f4f4"};
  border-radius: 12px;
  padding: 30px; /* Increased padding for better spacing */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  text-align: center;
  transition: background-color 0.3s ease, box-shadow 0.3s ease, transform 0.3s ease;

  &:hover {
    background-color: ${(props) => props.hoverColor || "#102C57"};
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
    transform: translateY(-3px); /* Elevação suave ao passar o mouse */
  }

  svg {
    font-size: 36px; /* Larger icon size */
    color: #ffffff;
    margin-bottom: 20px; /* More space between icon and text */
    transition: transform 0.3s ease;

    &:hover {
      transform: scale(1.2); /* Aumento do ícone ao passar o mouse */
    }
  }

  h2 {
    font-size: 20px;
    color: #ffffff;
    margin-bottom: 10px;
  }

  p {
    font-size: 22px; /* Increased font size for emphasis */
    color: #ffffff;
    font-weight: bold; /* Bold text for emphasis */
    margin-bottom: 5px; /* Spacing between each line */
  }

  /* Optional: You can add different styles for specific data points */
  p.total-vendas {
    font-size: 24px; /* Larger font for total sales */
    color: #ffe600; /* Gold color for emphasis */
  }

  p.total-tickets,
  p.total-produtos,
  p.total-custo {
    font-size: 20px;
    color: #b8d0e3; /* Softer color for less emphasis */
  }
`;

export const ReportItemFaturamento = styled(Report)`
  justify-content: center;
  align-items: center;
  grid-template-columns: 1fr; /* Uma coluna */
  margin: 0 auto; /* Centraliza horizontalmente */
  max-width: 500px; /* Ajuste o tamanho máximo, se necessário */
  gap: 0; /* Remove qualquer espaço extra */
  
  @media (max-width: 768px) {
    margin-bottom: 16px;
  }
`;


export const PeriodSelector = styled.select`
  margin-bottom: 20px;
  padding: 12px 15px;
  border-radius: 8px;
  border: 1px solid #a3b8cc;
  background-color: #102C57;
  color: #fff;
  font-size: 16px;
  font-weight: bold;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.08);
  transition: background-color 0.3s ease, transform 0.3s ease;

  &:focus {
    border-color: #b8d0e3;
    outline: none;
  }

  &:hover {
    background-color: #305780; /* Cor mais escura ao passar o mouse */
    transform: scale(1.02); /* Aumento suave ao passar o mouse */
  }

  @media (max-width: 768px) {
    width: 100%;
    font-size: 14px;
    margin-bottom: 10px; /* Ajuste de margem inferior no mobile */
  }
`;
export const PeriodSelectorOption = styled.option`
  font-weight: bold;
  transition: background-color 0.3s ease, color 0.3s ease;

  &:hover {
    background-color: #ffffff;
    color: #305780; /* Cor inversa ao passar o mouse */
  }
`;

export const MonthSelector = styled(PeriodSelector)`
  margin-left: 16px;

  @media (max-width: 768px) {
    margin-left: 0;
  }
`;

export const ShowMoreButton = styled.button`
  margin-top: 20px;
  padding: 12px 24px;
  background-color: #102C57;
  color: #ffffff;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  font-weight: bold;
  transition: background-color 0.3s ease, transform 0.2s ease;

  &:hover {
    background-color: #2e5480;
    transform: scale(1.05); /* Aumento suave ao passar o mouse */
  }

  @media (max-width: 768px) {
    width: 100%;
    font-size: 14px;
  }
`;

export const StyledChartWrapper = styled.div`
  width: 100%;
  max-width: 1500px;
  margin: 20px auto;
  padding: 30px;
  background: #f0f8ff; /* Light blue background */
  border-radius: 20px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1); /* More pronounced shadow */

  @media (max-width: 768px) {
    padding: 20px;
  }
`;

export const StyledReport = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 25px;
  margin-bottom: 25px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 20px;
  }
`;

export const StyledReportItem = styled.div`
  background-color: ${(props) => props.color || "#3498db"}; /* Default blue color */
  border-radius: 16px;
  padding: 35px; /* Increased padding */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15); /* Slightly deeper shadow */
  text-align: center;

  svg {
    font-size: 38px;
    color: #ffffff;
    margin-bottom: 18px;
  }

  h2 {
    font-size: 22px;
    color: #ffffff;
    margin-bottom: 12px;
  }

  p {
    font-size: 24px;
    color: #ffffff;
    font-weight: 600;
    margin-bottom: 6px;
  }

  p.total-vendas {
    font-size: 26px;
    color: #ffd700; /* Golden yellow */
  }

  p.total-tickets,
  p.total-produtos,
  p.total-custo {
    font-size: 22px;
    color: #a3c2f2; /* Softer blue */
  }
`;
