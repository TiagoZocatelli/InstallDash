import { useState, useEffect } from 'react';
import Chart from 'react-apexcharts';
import { fetchDepartamentoData } from '../../../api/APIDEP';
import { Container, Title, FilterContainer, Label, Select, ChartContainer, CardContainer, Card, CardTitle, CardValue, CardSubValue, LoadingMessage, DateInput, SearchButton } from './styles';
import { FaDollarSign, FaChartLine, FaMoneyBillWave, FaPercentage } from "react-icons/fa";

const Departamento = () => {
    const [departamentoData, setDepartamentoData] = useState([]);
    const [pieChartOptions, setPieChartOptions] = useState({});
    const [pieChartSeries, setPieChartSeries] = useState([]);
    const [otherData, setOtherData] = useState([]);
    const [selectedFilterType, setSelectedFilterType] = useState('departamento');
    const [selectedFilial, setSelectedFilial] = useState('');
    const [totalVendaGeral, setTotalVendaGeral] = useState(0);
    const [startDate, setStartDate] = useState(getDefaultStartDate());
    const [endDate, setEndDate] = useState(getDefaultEndDate());
    const [loading, setLoading] = useState(true);

    function getDefaultStartDate() {
        const now = new Date();
        now.setMonth(now.getMonth() - 2);
        return now.toISOString().split('T')[0];
    }

    function getDefaultEndDate() {
        return new Date().toISOString().split('T')[0];
    }

    const fetchData = async () => {
        setLoading(true);
        try {
            const data = await fetchDepartamentoData(startDate, endDate);
            setDepartamentoData(data || []);
            processAndSetChartData(data || [], selectedFilterType, selectedFilial);
        } catch (error) {
            console.error('Erro ao buscar dados do departamento:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); 

    useEffect(() => {
        if (departamentoData.length > 0) {
            processAndSetChartData(departamentoData, selectedFilterType, selectedFilial);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedFilterType, selectedFilial]);

    const processAndSetChartData = (data, filterType, filial) => {
        const chartData = processChartData(data, filterType, filial);
        setPieChartOptions(chartData.pieOptions);
        setPieChartSeries(chartData.pieSeries);
        setOtherData(chartData.other);
        setTotalVendaGeral(chartData.totalVendaGeral);
    };

    const processChartData = (data, filterType, filial) => {
        if (!Array.isArray(data) || data.length === 0) {
            console.error('Invalid data structure:', data);
            return {
                pieOptions: {},
                pieSeries: [],
                totalVendaGeral: 0
            };
        }

        let filteredData = data;
        if (filial) {
            filteredData = data.filter(item => item.filial === parseInt(filial));
        }

        let sortedData = [];
        if (filterType === 'departamento') {
            sortedData = [...filteredData].sort((a, b) => parseFloat(b.total_venda) - parseFloat(a.total_venda));
        } else if (filterType === 'grupo') {
            sortedData = filteredData.flatMap(item => item.grupos || []).sort((a, b) => parseFloat(b.total_venda) - parseFloat(a.total_venda));
        } else if (filterType === 'subgrupo') {
            sortedData = filteredData.flatMap(item =>
                (item.grupos || []).flatMap(grupo =>
                    (grupo.subgrupos || []).map(subgrupo => ({
                        subgrupo: subgrupo.subgrupo,
                        total_venda: subgrupo.total_venda,
                        total_custo: subgrupo.total_custo
                    }))
                )
            ).sort((a, b) => parseFloat(b.total_venda) - parseFloat(a.total_venda));
        }

        const totalVendaGeral = sortedData.reduce((acc, curr) => acc + parseFloat(curr.total_venda || 0), 0);

        const top10 = sortedData.slice(0, 10);
        const others = sortedData.slice(10);

        const categories = top10.map(item => {
            if (filterType === 'departamento') {
                return item.departamento?.trim() || 'Unknown';
            } else if (filterType === 'grupo') {
                return item.grupo?.trim() || 'Unknown';
            } else if (filterType === 'subgrupo') {
                return item.subgrupo?.trim() || 'Unknown';
            }
        });

        const salesSeries = top10.map(item => parseFloat(item.total_venda) || 0);
        const costSeries = top10.map(item => parseFloat(item.total_custo) || 0);
        const profitSeries = salesSeries.map((sale, index) => sale - costSeries[index]);

        const pieOptions = generatePieChartOptions(categories, salesSeries, costSeries, profitSeries, totalVendaGeral);
        const pieSeries = salesSeries;

        return { pieOptions, pieSeries, other: others, totalVendaGeral };
    };

    const generatePieChartOptions = (categories, salesSeries, costSeries, profitSeries, totalVendaGeral) => ({
        labels: categories,
        legend: {
            position: 'bottom'
        },
        tooltip: {
            y: {
                formatter: (val, { seriesIndex }) => {
                    return [
                        `Vendas: ${salesSeries[seriesIndex].toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`,
                        `Custo: ${costSeries[seriesIndex].toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`,
                        `Lucro: ${profitSeries[seriesIndex].toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`
                    ].join('<br/>');
                }
            }
        },
        dataLabels: {
            formatter: (val, opts) => {
                const percentage = (salesSeries[opts.seriesIndex] / totalVendaGeral * 100).toFixed(2);
                return `${percentage}%`;
            },
            style: {
                fontSize: '16px',
                fontWeight: 'bold'
            }
        }
    });

    const getFilialOptions = () => {
        const filiais = [...new Set(departamentoData.map(item => item.filial))];
        return filiais;
    };

    return (
        <Container>
            <Title>Departamento Vendas</Title>
            <FilterContainer>
                <Label>
                    Filial:
                    <Select value={selectedFilial} onChange={e => setSelectedFilial(e.target.value)}>
                        <option value="">Todas</option>
                        {getFilialOptions().map(filial => (
                            <option key={filial} value={filial}>{filial}</option>
                        ))}
                    </Select>
                </Label>
                <Label>
                    Tipo de Filtro:
                    <Select value={selectedFilterType} onChange={e => setSelectedFilterType(e.target.value)}>
                        <option value="departamento">Departamento</option>
                        <option value="grupo">Grupo</option>
                        <option value="subgrupo">Subgrupo</option>
                    </Select>
                </Label>
                <Label>
                    Data de Início:
                    <DateInput type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                </Label>
                <Label>
                    Data de Fim:
                    <DateInput type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
                </Label>
                <SearchButton onClick={fetchData}>Pesquisar</SearchButton>
            </FilterContainer>
            {loading ? (
                <LoadingMessage>Carregando dados do departamento...</LoadingMessage>
            ) : (
                pieChartSeries.length > 0 && (
                    <>
                        <ChartContainer>
                            <Chart 
                                options={pieChartOptions} 
                                series={pieChartSeries} 
                                type="pie" 
                                height={500}  
                            />
                        </ChartContainer>
                        <CardContainer>
                            {otherData.map((item, index) => (
                                <Card key={index}>
                                    <CardTitle><FaChartLine />{item.departamento?.trim() || item.grupo?.trim() || item.subgrupo?.trim()}</CardTitle>
                                    <CardValue><FaDollarSign />{parseFloat(item.total_venda).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</CardValue>
                                    <CardSubValue><FaMoneyBillWave />Custo: {parseFloat(item.total_custo).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</CardSubValue>
                                    <CardSubValue><FaDollarSign />Lucro: {(parseFloat(item.total_venda) - parseFloat(item.total_custo)).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</CardSubValue>
                                    <CardSubValue><FaPercentage />% do Faturamento: {((parseFloat(item.total_venda) / totalVendaGeral) * 100).toFixed(2)}%</CardSubValue>
                                </Card>
                            ))}
                        </CardContainer>
                    </>
                )
            )}
        </Container>
    );
};

export default Departamento;
