import styled from "styled-components";

export const Container = styled.div`
    max-width: 1500px;  
    margin: 0 auto;
    padding: 30px;  
    background-color: #f4f7fa;  
    border-radius: 12px;  
    box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.05);  
`;

export const Title = styled.h1`
    font-size: 2.5rem;  
    color: #34495e;
    text-align: center;
    margin-bottom: 30px;  
    font-weight: bold;  
`;

export const FilterContainer = styled.div`
    display: flex;
    flex-direction: column;
    gap: 15px;  
    margin-bottom: 30px;  

    @media (min-width: 768px) {
        flex-direction: row;
        justify-content: space-between;
    }
`;

export const Label = styled.label`
    font-size: 1.1rem;  
    color: #34495e;  
    display: flex;
    align-items: center;
    justify-content: space-between;
`;

export const Select = styled.select`
    margin-left: 12px;
    padding: 12px;  
    font-size: 1rem;
    border: 1px solid #34495e;  
    border-radius: 8px;  
    background-color: #ecf0f1;
    color: #34495e;
    transition: border-color 0.3s, box-shadow 0.3s;

    &:focus {
        outline: none;
        border-color: #2980b9;
        box-shadow: 0 0 8px rgba(41, 128, 185, 0.3);
    }
`;

export const DateInput = styled.input`
    padding: 12px;
    font-size: 1rem;
    border: 1px solid #34495e;
    border-radius: 8px;
    background-color: #ecf0f1;
    color: #34495e;
    margin-left: 12px;
    transition: border-color 0.3s, box-shadow 0.3s;

    &:focus {
        outline: none;
        border-color: #2980b9;
        box-shadow: 0 0 8px rgba(41, 128, 185, 0.3);
    }
`;

export const SearchButton = styled.button`
    padding: 12px 25px;
    font-size: 1rem;
    color: #fff;
    background-color: #34495e;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s;

    &:hover {
        background-color: #2980b9;
        transform: translateY(-2px);
        box-shadow: 0px 6px 12px rgba(41, 128, 185, 0.2);
    }

    &:active {
        background-color: #2c3e50;
    }
`;

export const ChartContainer = styled.div`
    margin-top: 30px;  
`;

export const CardContainer = styled.div`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 20px;
    justify-items: center;
    align-items: start;
    margin-top: 40px;  
    max-height: 450px;  
    overflow-y: auto;  
    overflow-x: hidden;

    @media (max-width: 768px) {
        display: block;
        justify-content: center;
    }

    &::-webkit-scrollbar {
        width: 8px;
    }

    &::-webkit-scrollbar-thumb {
        background-color: #2980b9;
        border-radius: 4px;
    }

    &::-webkit-scrollbar-track {
        background-color: #ecf0f1;
    }
`;

export const Card = styled.div`
    background-color: #102c57;
    border-radius: 16px;  
    box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.1);  
    padding: 30px; 
    margin: 16px auto;
    width: 100%;
    max-width: 320px;  
    text-align: center;
    transition: transform 0.3s, box-shadow 0.3s;  
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #ffffff;
    min-height: 300px;
    height: 300px; /* Set a fixed height for uniformity */

    /* Adjust height in responsive mode */
    @media (max-width: 768px) {
        min-height: auto; /* Allow height to adjust based on content */
        height: auto; /* Remove fixed height */
    }

    &:hover {
        transform: translateY(-5px);  
        box-shadow: 0px 12px 24px rgba(0, 0, 0, 0.15);  
    }
`;

export const CardTitle = styled.h3`
    font-size: 1.6rem;  
    margin-bottom: 15px;  
    font-weight: bold;
    color: #f39c12;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;  
    text-overflow: ellipsis; 
    white-space: nowrap;

    /* Responsive Adjustments */
    @media (max-width: 768px) {
        font-size: 1.4rem; /* Slightly smaller font size on smaller screens */
        white-space: normal; /* Allow text to wrap */
        text-align: center; /* Center text when wrapping */
        max-height: none; /* Remove max-height to allow wrapping */
    }

    & > svg {
        margin-right: 10px;
    }
`;


export const CardValue = styled.p`
    font-size: 2rem;  
    margin-top: 20px;
    margin-bottom: 10px;  
    font-weight: bold;
    color: #ecf0f1;
`;

export const CardSubValue = styled.p`
    font-size: 1.2rem;  
    color: #bdc3c7;
    margin: 5px 0;
`;

export const LoadingMessage = styled.p`
    text-align: center;
    font-size: 1.4rem;  
    color: #95a5a6;
    margin-top: 60px;  
`;