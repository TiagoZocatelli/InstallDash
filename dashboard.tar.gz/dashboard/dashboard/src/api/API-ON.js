import { loadConfig } from './apiConfig'; // Importa a função de configuração

export const fetchOnlineData = async () => {
  try {
    const baseUrl = await loadConfig(); // Obtém a URL base da API
    const response = await fetch(`${baseUrl}/finalizadorasonline`);

    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    const data = await response.json();
    console.log(data); // Log do resultado para entender a estrutura dos dados
    return data; // Retorna os dados completos

  } catch (error) {
    console.error('Erro ao buscar dados online:', error);
    throw error; // Re-lança o erro para ser tratado no componente
  }
};
