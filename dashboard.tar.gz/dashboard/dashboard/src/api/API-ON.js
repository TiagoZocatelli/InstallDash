const API_BASE_URL = 'http://192.168.15.8:8000';

export const fetchOnlineData = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/finalizadorasonline`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        console.log(data); // Log the entire response to understand its structure
        return data; // Return the entire data array
     
    } catch (error) {
        console.error('Erro ao buscar dados online:', error);
        throw error; // Re-throw the error to handle it in the component
    }
};
