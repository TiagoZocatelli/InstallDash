const API_BASE_URL = 'http://192.168.15.8:8000';

export const fetchVendasAndFaturamento = async (startDate, endDate) => {
  try {
    const [faturamentoResponse, vendasResponse] = await Promise.all([
      fetch(`${API_BASE_URL}/faturamento?start_date=${startDate}&end_date=${endDate}`),
      fetch(`${API_BASE_URL}/filter?start_date=${startDate}&end_date=${endDate}`)
    ]);

    if (!faturamentoResponse.ok || !vendasResponse.ok) {
      throw new Error('One or both network responses were not ok');
    }

    const faturamentoData = await faturamentoResponse.json();
    const vendasData = await vendasResponse.json();

    console.log('Faturamento Data:', faturamentoData);
    console.log('Vendas Mensais Data:', vendasData);
    console.log('Vendas Dia Data')

    return {
      resumoPorFilial: faturamentoData.resumo_por_filial,
      vendasMensais: vendasData.vendas_mensais,
      vendasDia: vendasData.vendas_dia,
    };

  } catch (error) {
    console.error('Erro ao buscar dados:', error);
    throw error;
  }
};