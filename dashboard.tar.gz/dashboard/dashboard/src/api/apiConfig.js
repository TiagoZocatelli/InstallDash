let apiBaseUrl = null;

// Função para carregar a URL base da API do arquivo config.json
export const loadConfig = async () => {
  if (!apiBaseUrl) {
    try {
      const response = await fetch('/config.json');
      if (!response.ok) {
        throw new Error('Failed to fetch config.json');
      }
      const config = await response.json();
      apiBaseUrl = config.API_BASE_URL;
    } catch (error) {
      console.error('Failed to load API base URL:', error);
      throw error;
    }
  }
  return apiBaseUrl;
};
