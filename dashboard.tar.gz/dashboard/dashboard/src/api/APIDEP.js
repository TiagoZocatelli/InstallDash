const API_BASE_URL = 'http://192.168.15.8:8000';

export const fetchDepartamentoData = async (startDate, endDate) => {
    try {
      const response = await fetch(`${API_BASE_URL}/vendas_departamento_grupo_subgrupo?start_date=${startDate}&end_date=${endDate}`);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      
      const data = await response.json();
      console.log(data); // Log the entire response to understand its structure
      return data; // Return the entire data array instead of `data.departamento`
     
    } catch (error) {
      console.error('Erro ao buscar dados do departamento:', error);
      throw error; // Re-throw the error to handle it in the component
    }
  };
  