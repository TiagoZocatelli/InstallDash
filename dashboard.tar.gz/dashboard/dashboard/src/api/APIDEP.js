import { loadConfig } from './apiConfig';

export const fetchDepartamentoData = async (startDate, endDate) => {
  try {
    const baseUrl = await loadConfig();
    const response = await fetch(`${baseUrl}/vendas_departamento_grupo_subgrupo?start_date=${startDate}&end_date=${endDate}`);
    
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    const data = await response.json();
    console.log(data); // Log the entire response to understand its structure
    return data; // Return the entire data array

  } catch (error) {
    console.error('Erro ao buscar dados do departamento:', error);
    throw error; // Re-throw the error to handle it in the component
  }
};
