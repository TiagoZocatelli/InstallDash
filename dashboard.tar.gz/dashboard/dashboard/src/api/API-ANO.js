import { loadConfig } from './apiConfig';

export const fetchComparativoAno = async () => {
  try {
    const baseUrl = await loadConfig();
    const response = await fetch(`${baseUrl}/comparativo_ano`);

    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    const comparativoData = await response.json();
    console.log('Comparativo Ano Data:', comparativoData);

    return comparativoData;

  } catch (error) {
    console.error('Erro ao buscar dados do comparativo ano:', error);
    throw error;
  }
};
