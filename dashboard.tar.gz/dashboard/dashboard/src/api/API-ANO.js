const API_BASE_URL = 'http://192.168.15.8:8000';


export const fetchComparativoAno = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/comparativo_ano`);
  
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
  
      const comparativoData = await response.json();
  
      console.log('Comparativo Ano Data:', comparativoData);
  
      return comparativoData;
  
    } catch (error) {
      console.error('Erro ao buscar dados do comparativo ano:', error);
      throw error;
    }
  };
  