const API_BASE_URL = 'http://192.168.15.8:8000';

export const fetchFinalizadoraData = async (startDate, endDate, filial = '') => {
    try {
        // Default to last three months if no dates are provided
        if (!startDate || !endDate) {
            const today = new Date();
            endDate = today.toISOString().split('T')[0];
            const threeMonthsAgo = new Date();
            threeMonthsAgo.setMonth(today.getMonth() - 3);
            startDate = threeMonthsAgo.toISOString().split('T')[0];
        }

        // Build the API URL with optional filial parameter
        let apiUrl = `${API_BASE_URL}/finalizadoras_periodo?data_inicial=${startDate}&data_final=${endDate}`;
        if (filial) {
            apiUrl += `&filial=${filial}`;
        }

        // Make the API request
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        console.log('Finalizadoras',data)
        return data;
    } catch (error) {
        console.error('Erro ao buscar dados online:', error);
        throw error;
    }
};
