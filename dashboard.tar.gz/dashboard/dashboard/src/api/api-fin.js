import { loadConfig } from './apiConfig';

export const fetchFinalizadoraData = async (startDate, endDate, filial = '') => {
  try {
    const baseUrl = await loadConfig();

    if (!startDate || !endDate) {
      const today = new Date();
      endDate = today.toISOString().split('T')[0];
      const threeMonthsAgo = new Date();
      threeMonthsAgo.setMonth(today.getMonth() - 3);
      startDate = threeMonthsAgo.toISOString().split('T')[0];
    }

    let apiUrl = `${baseUrl}/finalizadoras_periodo?data_inicial=${startDate}&data_final=${endDate}`;
    if (filial) {
      apiUrl += `&filial=${filial}`;
    }

    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    const data = await response.json();
    console.log('Finalizadoras', data);
    return data;

  } catch (error) {
    console.error('Erro ao buscar dados online:', error);
    throw error;
  }
};
