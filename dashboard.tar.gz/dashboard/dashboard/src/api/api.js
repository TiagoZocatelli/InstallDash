let apiBaseUrl = null;

// Function to load the API base URL from the config.json file
const loadConfig = async () => {
  if (!apiBaseUrl) {
    try {
      const response = await fetch('/public/config.json');
      if (!response.ok) {
        throw new Error('Failed to fetch config.json');
      }
      const config = await response.json();
      apiBaseUrl = config.API_BASE_URL;
    } catch (error) {
      console.error('Failed to load API base URL:', error);
      throw error;
    }
  }
  return apiBaseUrl;
};

// Fetch function for vendas and faturamento data
export const fetchVendasAndFaturamento = async (startDate, endDate) => {
  try {
    const baseUrl = await loadConfig();
    const [faturamentoResponse, vendasResponse] = await Promise.all([
      fetch(`${baseUrl}/faturamento?start_date=${startDate}&end_date=${endDate}`),
      fetch(`${baseUrl}/filter?start_date=${startDate}&end_date=${endDate}`)
    ]);

    if (!faturamentoResponse.ok || !vendasResponse.ok) {
      throw new Error('One or both network responses were not ok');
    }

    const faturamentoData = await faturamentoResponse.json();
    const vendasData = await vendasResponse.json();

    console.log('Faturamento Data:', faturamentoData);
    console.log('Vendas Mensais Data:', vendasData);

    return {
      resumoPorFilial: faturamentoData.resumo_por_filial,
      vendasMensais: vendasData.vendas_mensais,
      vendasDia: vendasData.vendas_dia,
    };

  } catch (error) {
    console.error('Erro ao buscar dados:', error);
    throw error;
  }
};

